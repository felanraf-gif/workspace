"""Run VM acceptance checks on an operator-created candidate checkout.

Never installs services, modifies accounts, approves user patches or bypasses
kernel isolation. Writes logs outside the repository and temporary test data
under work/validation. Run with python3 -B test_vm.py --help.
"""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import xml.etree.ElementTree as ET


def run(command, cwd, env, log, timeout):
    with log.open('x') as output:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            status = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            print('BLOCKED: timeout; inspect ' + str(log))
            return False
    print(f'exit={status}; log={log}')
    return status == 0


def snapshot(repo):
    excluded = {'.git', '.venv', 'work', '__pycache__', '.pytest_cache'}
    result = {}
    for base, dirs, files in os.walk(repo, followlinks=False):
        dirs[:] = [name for name in dirs if name not in excluded]
        for name in files:
            path = Path(base) / name
            if path.is_symlink():
                result[str(path.relative_to(repo))] = 'symlink:' + os.readlink(path)
            else:
                result[str(path.relative_to(repo))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True)
    parser.add_argument('--python', required=True)
    parser.add_argument('--workspace-root', required=True)
    parser.add_argument('--results', required=True, help='New directory outside the checkout')
    args = parser.parse_args()
    repo = Path(args.repo).resolve(strict=True)
    python = Path(args.python).absolute()  # Keep venv path, not its interpreter symlink.
    base = Path(args.workspace_root).resolve(strict=True)
    results = Path(args.results).absolute()
    if results.resolve().is_relative_to(repo):
        parser.error('Results must be outside the checkout')
    if not (repo / '.git').is_dir() or not python.is_file():
        parser.error('Use a separate ordinary Git checkout and its venv')
    results.mkdir(exist_ok=False, parents=True)
    # Do not propagate provider credentials or application authorization.
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(Path.home()), 'LANG': 'C.UTF-8',
           'OBSERVER_MODE': 'true', 'INTEGRATE_OBSIDIAN': 'false',
           'INTEGRATE_TODOIST': 'false', 'PYTHONDONTWRITEBYTECODE': '1',
           'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'}
    fixtures = repo / 'work/validation'
    existing = set(fixtures.iterdir()) if fixtures.exists() else set()
    try:
        if not run([str(python), '-B', 'scripts/validate.py'], repo, env,
                   results / '01-suite.log', 120):
            return 1
        xml = results / 'landlock.xml'
        if not run([str(python), '-B', '-m', 'pytest', 'tests/test_operator_apply.py',
                    '-q', '-p', 'no:cacheprovider', '-k', 'real_landlock',
                    '--junitxml=' + str(xml)], repo, env,
                   results / '02-landlock.log', 60):
            return 1
        tests = ET.parse(xml).getroot().findall('.//testcase')
        if len(tests) != 2 or any(test.find(tag) is not None for test in tests
                                  for tag in ('skipped', 'failure', 'error')):
            print('BLOCKED: both real Landlock tests must run and pass; skipped is not PASS')
            return 1
    finally:
        # Remove only fixtures created by these runs, never pre-existing data.
        if fixtures.exists():
            for item in set(fixtures.iterdir()) - existing:
                if item.is_dir() and not item.is_symlink():
                    shutil.rmtree(item)
                else:
                    item.unlink()
    command = [str(python), '-B', 'scripts/observer_sandbox.py', '--repo', str(repo),
               '--python', str(python), '--workspace-root', str(base)]
    if not run(command + ['--probe'], repo, env, results / '03-sandbox-probe.log', 45):
        return 1
    before = snapshot(repo)
    if not run(command, repo, env, results / '04-observer.log', 210):
        return 1
    if '[STOP] Requested cycles completed.' not in (results / '04-observer.log').read_text():
        print('BLOCKED: missing completed-cycle message')
        return 1
    if before != snapshot(repo):
        print('BLOCKED: source-file snapshot changed during Observer cycle')
        return 1
    print('PASS: suite, two real Landlock tests, write-denial probe and isolated Observer cycle')
    print('Snapshot excludes .git, .venv, work and caches; this is not a whole-machine audit.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
