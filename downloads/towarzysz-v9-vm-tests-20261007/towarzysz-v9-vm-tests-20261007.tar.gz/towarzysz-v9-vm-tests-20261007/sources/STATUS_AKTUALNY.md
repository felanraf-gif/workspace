# Towarzysz V9 — stan zweryfikowanej kopii, 26.09.2026

## Aktualizacja chmurowa, 07.10.2026 — bieżący stan

Do repozytorium `workspace` przeniesiono aktualne zwykłe pliki z archiwum
`towarzysz-v9-M0-audit-20260928.tar.gz`, bez `.git`, `.env` i danych
`work/validation`. Archiwum przed poprawkami przeszło tutaj 130 testów,
z jednym celowo wyłączonym testem. Liczby z wcześniejszych sekcji opisują
historyczne wersje i środowiska.

Po wprowadzonych zmianach runner `scripts/validate.py` zakończył się kodem 0:
**145 PASS, 2 SKIPPED, 1 DESELECTED**. Pominięte są dwie próby prawdziwego
Landlock (zwykły zapis i przeniesienie katalogu po kontroli), a celowo
wyłączony pozostaje historyczny test wymagający chmod. Parsowanie AST
106 plików Python oraz `git diff --check` zakończyły się poprawnie.

Zamknięto odtworzony przypadek przeniesienia katalogu docelowego w trakcie
potwierdzania: kontroler zachowuje deskryptory katalogów i sprawdza ich
tożsamość oraz granice zagnieżdżonych repozytoriów przed wykonaniem. Dodatkowo
zapis odbywa się wyłącznie w procesie potomnym ograniczonym Linux Landlock
ABI ≥ 3. Landlock ogranicza skutki zapisu do przypiętego katalogu repozytorium,
a nie tylko do ścieżki sprawdzonej wcześniej. Plik tymczasowy jest tworzony
w katalogu głównym, aby otwarty deskryptor zapisu nie podążał za przeniesionym
podkatalogiem. Brak możliwości ustanowienia granicy jądra oznacza odmowę,
bez zapisu. Zmiana nazwy całego repozytorium nie zmienia tożsamości przypiętej
granicy Landlock; nie należy utożsamiać jej z niezmienną nazwą ścieżki.

Poprawiono diff treści bez końcowej nowej linii. Launcher obsługuje jawny
`--workspace-root /workspace`, ukrywa pozostałą zawartość tego katalogu
i HOME, zachowując dotychczasowe wymagania zaufania do bubblewrap.

W tej chmurze Landlock zwraca ENOSYS, również poza sandboxem narzędzia;
nie potwierdzono, czy przyczyną jest konfiguracja jądra czy filtr syscalli.
`/usr/bin/bwrap` ma widocznego właściciela UID 65534, zamiast wymaganego 0;
bezpośrednia sonda przestrzeni użytkownika zwróciła błąd read-only uid map.
Nie osłabiono kontroli właściciela ani nie ominięto wymagania izolacji.
Ręczny zapis oraz izolowany cykl Observera pozostają tutaj niedostępne.
Testy rzeczywistego Landlock są jawnie pomijane, a test mechaniki zapisu
z użyciem atrapionej granicy nie jest dowodem działania izolacji OS.

Wcześniejszy jednorazowy cykl aplikacyjnego Observer Mode na odtworzonej
kopii zakończył się kodem 0, z zablokowanym Builderem i identycznymi SHA-256
zwykłych plików przed i po cyklu. Nie był uruchomiony przez launcher;
ten wynik nie dowodzi izolacji OS. Testy nie włączają produkcyjnej usługi,
integracji zewnętrznych ani autonomicznego Buildera.

## Jednorazowy cykl w izolacji, 26.09.2026

Rafał uruchomił na VM zestaw testów: 125 PASS, 1 celowo wyłączony;
`git diff --check` zakończył się pomyślnie. Sonda `bubblewrap`
potwierdziła odmowę zapisu w repozytorium przez system operacyjny.
Następnie jednorazowy cykl Observer zakończył się komunikatem
`[STOP] Requested cycles completed.` Builder pozostał zablokowany;
integracje i utrwalenie stanu były blokowane. `Ctrl+C` naciśnięte po
powrocie do powłoki dało kod 130 dla ostatniej akcji terminala, a nie
wynik zakończonego cyklu. Nie wykonano porównania całego drzewa plików
przed i po cyklu, więc nie należy tego twierdzić na podstawie samej sondy.

Log wskazał fałszywe propozycje dotyczące `work/validation`, zgłoszenia
„martwego kodu” dla skryptów i testów oraz zadanie patch bez celu.
Następna lokalna poprawka ogranicza te wyniki i wymaga walidacji na VM.
Na prawdziwych plikach użytkownika cyklu jeszcze nie uruchomiono.

## Aktualizacja przeglądu, 26.09.2026

**Kolejny etap roboczy:** osobny `cli/operator_apply.py` może po ręcznym
potwierdzeniu zastosować dokładnie jedną istniejącą zmianę tekstową w innym
repozytorium. `scripts/observer_sandbox.py` przygotowuje izolowane, odczytowe
uruchomienie Towarzysza z użyciem `bubblewrap` i odmawia startu przy błędzie
izolacji. Rozwiązanie przeszło sondę i pojedynczy cykl na VM; nie łączy
automatycznie zadań Observera z propozycjami gotowymi do zastosowania.
Usługa i tryb wykonawczy nadal pozostają wyłączone.

Po wszystkich poprawkach Rafał uruchomił walidację na VM: 115 PASS,
1 celowo wyłączony; `git diff --check` zakończył się bez błędów. Dwa
jednorazowe cykle Observer Mode na repo audytowym (przed i po zamknięciu
obejść zgody) zakończyły się kodem 0, wykryły jeden projekt, zablokowały
Builder i nie zmieniły żadnego pliku ani katalogu w kontrolowanym drzewie.
124 pliki oznaczone jako „nowe” w każdym procesie to pierwszy odczyt
obserwatora, którego stan początkowy jest pusty. Porównanie nie obejmowało
ścieżek poza repo ani ruchu sieciowego.

Ostatnia poprawka blokuje bezpośrednie zapisy `FileTools` i zapisy
stanu runtime w trybie wykonawczym. `scoped_open` oraz usuwanie plików wymagają
teraz aktywnej, jednorazowej zgody na paczkę PatchEngine; rollback po błędzie
odbywa się w jej zakresie, a osobny ręczny rollback jest blokowany.
To jest kontrola aplikacyjna w tym samym procesie i UID, nie niezależna
izolacja. Poprawka została zastosowana i zweryfikowana na VM; do czasu
niezależnej kontroli zgody i wykonania pozostaje wyłącznie Observer Mode.

Poniższy tekst z 25.09 jest zapisem wcześniejszego etapu, nie aktualną
deklaracją gotowości. Przekazany z VM wynik wcześniejszej kopii to 109 PASS,
1 test wyłączony; zdalny `master` ma starsze pliki. Usługa systemd jest
nieaktywna i wskazuje `/home/felanraf/Projekty/workspace`, a nie repo audytowe.
Rafał wybrał jedno konto `felanraf`; plan osobnego konta jest historyczny.
Archiwum z 26.09 zawiera historię `.git` i dane testowe `work/validation`
z dowiązaniami; nie publikować go jako wydania ani nie rozpakowywać dowiązań
bez sprawdzenia. Ocena w tej sesji dotyczy odtworzonych zwykłych plików kodu.

Przegląd wcześniejszego kodu wykazał, że odcisk poprawki sprawdzał wyłącznie
PatchEngine. `FileTools.write`, `core/observer_storage.open` i `scoped_open`
były innymi wejściami zapisu przy `OBSERVER_MODE=false` i autoryzowanym repo.
To nie jest niezależna zgoda ani izolacja OS na jednym UID. Nie włączać
trybu wykonawczego ani obecnej usługi systemd. Pierwsze lokalne uruchomienie
może być jednorazową obserwacją po sprawdzeniu środowiska i danych wejściowych.

Poprawka robocza z tego przeglądu nie przyjmuje już `AUTHORIZED_REPO`,
`OBSERVER_MODE` ani `TOWARZYSZ_APPROVED_PATCH_SHA256` z projektowego `.env`.
Pełny zestaw testów po tej poprawce uruchomiono następnie na VM.

Kolejny etap przygotowania pojedynczego cyklu: jawnie wskazane repozytorium
jest rozpoznawane jako jeden projekt, bez zamiany jego podkatalogów w projekty.
Obserwator i metryki pomijają `work` oraz dowiązania plików, aby nie czytać
testowych danych poza zakresem wybranego katalogu. Sprawdzono to w izolowanym
katalogu testowym i przez parsowanie AST; pełną regresję pytest wykonano
następnie na VM. Ta poprawka nie włącza zapisów ani usługi.

## Zakres i pochodzenie
Źródło: archiwum użytkownika oraz poprawki audytu z tej rozmowy. Archiwum nie zawiera historii lokalnego Git, .env ani kompletu danych runtime. To nie jest pełna kopia komputera. Planowana gałąź audytu ma zawierać snapshot źródeł oparty na zdalnym master; nie odtworzy brakujących lokalnych commitów. Publikacja wymaga weryfikacji zdalnej gałęzi; jej wynik podaje raport dostawy poza snapshotem.

## Naprawy
- P1 Git: pomijanie submodułów i jawny format log zapobiegają wykonaniu helperów w sprawdzonych scenariuszach.
- Observer: wyłącznie wartość false (po normalizacji) pozwala wyłączyć obserwację. Brak, pusty ciąg i literówki pozostawiają blokadę.
- PatchEngine: auto_confirm=False odmawia zapisu przed backupem i zmianą pliku.
- Poprawiono nazwy wersji, komunikat o commicie i zależności testowe.
- Dodano powtarzalny runner scripts/validate.py z lokalnymi danymi testowymi.

## Dowody
Poprzedni audyt: 87 PASS / 4 FAIL przed naprawą P1, następnie 91 PASS.
Bieżący etap: sześć nowych przypadków FAIL przed poprawką. Po poprawce: 96 PASS, 1 deselected (3.43 s).
Pominięty test test_observer_git_signature_config używa chmod. Testy test_r1_git_helpers nadal obejmują uruchamianie weryfikatora podpisu i filtrów submodułów, w obu trybach.
Sprawdzono AST aktywnego kodu i bash -n run_da.sh. Nie uruchamiano produkcyjnego agenta ani integracji.

## Rzeczywiste granice
R1 to kontrola wejść aplikacji, nie izolacja OS. OBSERVER_MODE pozostaje dynamiczne. R3 (ochrona własnych zabezpieczeń) i R4 (zakaz rozszerzania zakresu) nie są w pełni egzekwowane. R5 rozdziela analizę od wykonania w observer. R6 wzmocniono dla konfiguracji trybu, ale nie jest to dowód kompletnego fail-closed całego systemu.
Brak niezależnej zgody na konkretny diff. auto_confirm=True i AUTHORIZED_REPO nie zastępują takiej zgody. PatchEngine nie sprawdza aktualności old_code przed nadpisaniem; walidacja składni nie dowodzi zachowania semantyki. Przed produkcyjnymi zapisami potrzebne są dalsze prace.
DependencyGraph to heurystyka; wyniki wymagają przeglądu. VectorMemory wyszukuje słowa, nie embeddingi. Pamięć JSON nie ma kompletnej odporności na przerwany zapis. Odczyty mają szeroki zakres, bez kompletnej klasyfikacji sekretów. Nie deklarujemy kompletnego audytu każdej linii ani całego systemu.

## Kopia 1:1
Katalog release i jego lokalna kopia mają te same ścieżki i bajty plików, potwierdzone SHA-256. Ten sam zestaw jest przeznaczony do nowej gałęzi Git. Zakres obejmuje kod, testy, skrypty, dokumentację i konfigurację przykładową. Wykluczono sekrety, środowiska, dane runtime, logi i fixture testowe. Manifest nie obejmuje siebie.
Pliki historyczne zachowano i oznaczono. Ta strona ma pierwszeństwo przed dawnymi wynikami oraz deklaracjami.

## Następny krok
Porównać snapshot z aktualnym drzewem na laptopie; wykonać pełny backup tamtejszego repozytorium z jego wspólnymi metadanymi worktree przed przeniesieniem zmian.

## Kontrola publikacji
Automatyczna kontrola odrzuciła pierwszą próbę utworzenia drzewa Git: historyczny token Todoist w WORKFLOW.md. Wartość zastąpiono REDACTED_TODOIST_TOKEN. Token należy unieważnić u dostawcy; sama redakcja nie cofa wcześniejszego ujawnienia. Kopia 1:1 dotyczy oczyszczonego zestawu wydania, nie oryginalnego archiwum z laptopa.

Ponowna próba publikacji została odrzucona przez automatyczną kontrolę: publiczne repozytorium felanraf-gif/workspace oraz dokumentacja ze ścieżkami lokalnymi i szczegółami środowiska wymagają potwierdzenia dokładnego celu i zakresu. Nie utworzono gałęzi ani commita. Archiwum i lokalna kopia są gotowe.

## Zgoda i kompletność założeń
Rafał zatwierdził publikację oczyszczonego wydania do publicznego felanraf-gif/workspace na nowej gałęzi oraz identyczną kopię lokalną. Poprzednie odmowy opisane wyżej są historią prób. Aktualna macierz wymagań: docs/bezpieczenstwo/zalozenia-i-pokrycie-2026-09-25.md. Rozróżnia zasady R1–R6, zgody, niezależność ról, zewnętrzny bezpiecznik, ochronę danych i faktyczne luki.

## Następny blok — zgoda na treść patcha (lokalna poprawka robocza)
Domyślnie PatchEngine i Builder odmawiają zapisania kandydatów, nawet przy wysokiej pewności i `auto_confirm=True`. Kontrola porównuje SHA-256 kanonicznego opisu repozytorium, uporządkowanej listy celów, starej i nowej treści, typu i opisu problemu z wartością `TOWARZYSZ_APPROVED_PATCH_SHA256` przechwyconą na starcie procesu. Zmiana propozycji lub późna zmiana środowiska unieważnia zgodę. Dotychczasowe testy zapisu i rollbacku symulują zgodę zewnętrzną przez fixture.
Nie ma jeszcze niezależnego ekranu do przeglądu diffu i bezpiecznego wystawienia zatwierdzenia człowieka. Ustawienie zmiennej bez obejrzenia konkretnej propozycji nie jest zgodą. Ten mechanizm działa w zaufanym procesie i nie izoluje kodu zabezpieczeń; chroni przed wskazanymi błędami aplikacji, nie przed złośliwym kodem z uprawnieniami procesu. Dopóki przepływ zatwierdzenia nie zostanie zweryfikowany, pracować w trybie Observer. Po tym bloku testy w izolowanej kopii: 103 passed, 1 deselected; test produkcyjnego cyklu nie był wykonywany.

Doprecyzowanie: zatwierdzony odcisk jest zużywany atomowo przy pierwszej zgodnej próbie (również gdy późniejsza walidacja się nie powiedzie). Restart z nową, świadomą zgodą jest wymagany do ponownej próby. Test regresyjny blokuje powtórzenie po ręcznym rollbacku.
