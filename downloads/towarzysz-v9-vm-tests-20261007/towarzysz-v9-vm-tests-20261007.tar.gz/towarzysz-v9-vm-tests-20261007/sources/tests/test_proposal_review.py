"""The preview cannot become an approval or a write path."""
import json

import pytest

from cli.proposal_review import load_proposal, main, render


def proposal(tmp_path, path='module.py'):
    repo = tmp_path / 'repo'
    repo.mkdir()
    target = repo / 'module.py'
    target.write_text('VALUE = 1\n')
    request = tmp_path / 'request.json'
    request.write_text(json.dumps({
        'schema_version': 1, 'project': 'example', 'root': str(repo),
        'description': 'Przykładowa zmiana', 'priority': 'HIGH',
        'changes': [{'path': path, 'old_code': 'VALUE = 1\n', 'new_code': 'VALUE = 2\n'}],
    }))
    return request, target


@pytest.mark.parametrize('selection', ['z', 'p', 'o'])
def test_each_decision_leaves_files_and_approval_untouched(tmp_path, monkeypatch, selection):
    from core import observer_policy as policy
    request, target = proposal(tmp_path)
    monkeypatch.setattr(policy, '_APPROVED_PATCH_DIGEST', None)
    responses = iter([selection, 'Zmień zakres'])
    output = []
    assert main([str(request)], input_fn=lambda _: next(responses), output_fn=output.append) == 0
    assert target.read_text() == 'VALUE = 1\n'
    assert policy._APPROVED_PATCH_DIGEST is None
    assert '--- a/module.py' in output[0]
    assert '+++ b/module.py' in output[0]


def test_bad_path_is_rejected_and_terminal_escape_is_printed_literally(tmp_path):
    request, _ = proposal(tmp_path, '../outside.py')
    with pytest.raises(ValueError):
        load_proposal(request)
    data = json.loads(request.read_text())
    data['changes'][0]['path'] = 'module.py'
    data['description'] = 'text\x1b[2Jclear'
    request.write_text(json.dumps(data))
    shown = render(load_proposal(request))
    assert '\x1b' not in shown
    assert r'\x1b[2Jclear' in shown


def test_directional_control_cannot_reverse_visible_diff(tmp_path):
    request, _ = proposal(tmp_path)
    data = json.loads(request.read_text())
    data['description'] = 'Bezpieczny tekst\u202eukryty'
    request.write_text(json.dumps(data))
    shown = render(load_proposal(request))
    assert '\u202e' not in shown
    assert r'\u202e' in shown


@pytest.mark.parametrize('old,new,markers', [
    ('x=1', 'x=2', 2), ('x=1\n', 'x=2', 1), ('x=1', 'x=2\n', 1),
    ('x=1\n', 'x=2\n', 0), ('', 'x=2', 1), ('x=1', '', 1),
])
def test_diff_separates_lines_and_marks_missing_final_newline(tmp_path, old, new, markers):
    request, _ = proposal(tmp_path)
    data = json.loads(request.read_text())
    data['changes'][0].update(old_code=old, new_code=new)
    shown = render(data)
    assert shown.count('\\ No newline at end of file') == markers
    if old:
        assert '-x=1\n' in shown
    if new:
        assert '+x=2\n' in shown
    assert '-x=1+x=2' not in shown
