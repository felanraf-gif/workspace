"""The operator, not an agent task, decides and executes one concrete diff."""

import hashlib
import json
import os
import stat
import sys
import subprocess
from pathlib import Path

import pytest

from cli.operator_apply import main
from cli import operator_apply as operator


def test_operator_import_does_not_initialize_agent():
    result = subprocess.run([sys.executable, '-B', '-c',
        "import cli.operator_apply, sys; "
        "assert 'brain.analyzer' not in sys.modules; "
        "assert 'core.observer_policy' not in sys.modules"],
        cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def request(tmp_path, *, path='module.py', old='VALUE = 1\n', new='VALUE = 2\n'):
    repo = tmp_path / 'repo'
    repo.mkdir()
    (repo / '.git').mkdir()
    target = repo / 'module.py'
    target.write_text('VALUE = 1\n')
    proposal = {'schema_version': 1, 'project': 'sample', 'root': str(repo),
                'description': 'Zmień wartość', 'priority': 'LOW',
                'changes': [{'path': path, 'old_code': old, 'new_code': new}]}
    source = tmp_path / 'proposal.json'
    source.write_text(json.dumps(proposal))
    digest = hashlib.sha256(json.dumps(proposal, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':')).encode('utf-8')).hexdigest()
    return repo, target, source, 'ZASTOSUJ ' + digest[:16]


def call(source, repo, phrase, *, tty=True, input_fn=None):
    output = []
    code = main([str(source), str(repo)],
                tty_fn=lambda: tty,
                input_fn=input_fn or (lambda _: phrase), output_fn=output.append)
    return code, output


def test_operator_requires_terminal_and_exact_confirmation(tmp_path):
    repo, target, source, phrase = request(tmp_path)
    for tty, answer in ((False, phrase), (True, 'z'), (True, '')):
        code, _ = call(source, repo, answer, tty=tty)
        assert code != 0
        assert target.read_text() == 'VALUE = 1\n'
        assert sorted(item.name for item in repo.iterdir()) == ['.git', 'module.py']


def test_replacement_preserves_metadata_with_mocked_kernel_boundary(tmp_path, monkeypatch):
    # Unit test of replacement mechanics. Real confinement is tested separately.
    monkeypatch.setattr(operator, 'restrict_writes', lambda _: None)
    repo, target, source, phrase = request(tmp_path)
    before = target.stat()
    code, output = call(source, repo, phrase)
    after = target.stat()
    assert code == 0
    assert target.read_text() == 'VALUE = 2\n'
    assert (before.st_uid, before.st_gid, stat.S_IMODE(before.st_mode)) == (
        after.st_uid, after.st_gid, stat.S_IMODE(after.st_mode))
    assert any('Zastosowano jedną zmianę' in line for line in output)
    assert sorted(item.name for item in repo.iterdir()) == ['.git', 'module.py']
    assert call(source, repo, phrase)[0] != 0  # Old content is no longer current.


def test_stale_or_changed_during_review_is_rejected(tmp_path):
    repo, target, source, phrase = request(tmp_path)
    target.write_text('VALUE = 5\n')
    assert call(source, repo, phrase)[0] != 0
    target.write_text('VALUE = 1\n')
    def changed(_):
        target.write_text('VALUE = 5\n')
        return phrase
    assert call(source, repo, phrase, input_fn=changed)[0] != 0
    assert target.read_text() == 'VALUE = 5\n'


def test_symlink_hardlink_nested_repo_and_agent_code_rejected(tmp_path):
    repo, target, source, phrase = request(tmp_path)
    outside = tmp_path / 'outside.py'
    outside.write_text('VALUE = 1\n')
    target.unlink()
    target.symlink_to(outside)
    assert call(source, repo, phrase)[0] != 0
    target.unlink()
    os.link(outside, target)
    assert call(source, repo, phrase)[0] != 0
    assert outside.read_text() == 'VALUE = 1\n'
    target.unlink()
    target.write_text('VALUE = 1\n')
    nested = repo / 'nested'
    nested.mkdir()
    (nested / '.git').mkdir()
    (nested / 'module.py').write_text('VALUE = 1\n')
    data = json.loads(source.read_text())
    data['changes'][0]['path'] = 'nested/module.py'
    source.write_text(json.dumps(data))
    assert call(source, repo, phrase)[0] != 0
    (repo / 'main.py').write_text('')
    (repo / 'core').mkdir()
    (repo / 'core/observer_policy.py').write_text('')
    (repo / 'brain').mkdir()
    (repo / 'brain/patch_engine.py').write_text('')
    assert call(source, repo, phrase)[0] != 0


def test_multiple_files_or_creation_denied(tmp_path):
    repo, target, source, phrase = request(tmp_path)
    data = json.loads(source.read_text())
    data['changes'].append({'path': 'new.py', 'old_code': None, 'new_code': 'x = 1\n'})
    source.write_text(json.dumps(data))
    assert call(source, repo, phrase)[0] != 0
    data['changes'] = [data['changes'][-1]]
    source.write_text(json.dumps(data))
    assert call(source, repo, phrase)[0] != 0
    assert target.read_text() == 'VALUE = 1\n'


@pytest.mark.parametrize('kind', ['parent', 'root', 'nested_repo', 'symlink_parent'])
def test_directory_scope_changed_during_confirmation_is_rejected(tmp_path, kind):
    repo, target, source, _ = request(tmp_path)
    sub = repo / 'src'
    sub.mkdir()
    target.rename(sub / 'module.py')
    data = json.loads(source.read_text())
    data['changes'][0]['path'] = 'src/module.py'
    source.write_text(json.dumps(data))
    digest = hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':')).encode('utf-8')).hexdigest()
    outside = tmp_path / 'outside'

    def changed(_):
        if kind == 'root':
            repo.rename(outside)
        elif kind == 'nested_repo':
            (sub / '.git').mkdir()
        else:
            sub.rename(outside)
            if kind == 'symlink_parent':
                sub.symlink_to(outside, target_is_directory=True)
        return 'ZASTOSUJ ' + digest[:16]

    assert call(source, repo, '', input_fn=changed)[0] != 0
    surviving = (outside / 'src/module.py' if kind == 'root' else
                 sub / 'module.py' if kind == 'nested_repo' else outside / 'module.py')
    assert surviving.read_text() == 'VALUE = 1\n'
    assert not list(tmp_path.rglob('.towarzysz-operator-*'))


def test_unavailable_kernel_boundary_refuses_all_writes(tmp_path, monkeypatch):
    repo, target, source, phrase = request(tmp_path)

    def unavailable(_):
        raise OSError('Landlock unavailable')

    monkeypatch.setattr(operator, 'restrict_writes', unavailable)
    code, output = call(source, repo, phrase)
    assert code != 0
    assert 'Landlock unavailable' in output[-1]
    assert target.read_text() == 'VALUE = 1\n'
    assert sorted(p.name for p in repo.iterdir()) == ['.git', 'module.py']


@pytest.mark.parametrize('move_after_check', [False, True])
def test_real_landlock_replacement_and_concurrent_move(tmp_path, monkeypatch, move_after_check):
    """Exercise the kernel; never substitute a mock for these assertions."""
    repo, target, source, _ = request(tmp_path)
    sub = repo / 'src'
    sub.mkdir()
    target.rename(sub / 'module.py')
    data = json.loads(source.read_text())
    data['changes'][0]['path'] = 'src/module.py'
    source.write_text(json.dumps(data))
    digest = hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':')).encode('utf-8')).hexdigest()
    # Restrict only a subprocess when checking kernel availability.
    probe = subprocess.run([sys.executable, '-B', '-c',
        'import os,sys; from cli.write_confinement import restrict_writes; '
        'fd=os.open(sys.argv[1], os.O_RDONLY|os.O_DIRECTORY); restrict_writes(fd)',
        str(repo)], capture_output=True, text=True)
    if probe.returncode:
        pytest.skip('Real Landlock confinement unavailable: ' + probe.stderr.strip().splitlines()[-1])
    outside = tmp_path / 'outside'
    if move_after_check:
        # Parent process remains unrestricted; move the target directory after
        # the child has validated it, immediately before its write syscall.
        start_read, start_write = os.pipe()
        done_read, done_write = os.pipe()
        original_replace = operator._replace

        def racing_replace(*args):
            os.write(start_write, b'1')
            assert os.read(done_read, 1) == b'1'
            return original_replace(*args)

        monkeypatch.setattr(operator, '_replace', racing_replace)
        mover = os.fork()
        if mover == 0:
            try:
                assert os.read(start_read, 1) == b'1'
                sub.rename(outside)
                os.write(done_write, b'1')
                os._exit(0)
            except BaseException:
                os._exit(1)
        try:
            code, _ = call(source, repo, 'ZASTOSUJ ' + digest[:16])
        finally:
            _, status = os.waitpid(mover, 0)
            for fd in (start_read, start_write, done_read, done_write):
                os.close(fd)
        assert status == 0
        assert code != 0
        assert (outside / 'module.py').read_text() == 'VALUE = 1\n'
        assert not list(outside.glob('.towarzysz-operator-*'))
    else:
        assert call(source, repo, 'ZASTOSUJ ' + digest[:16])[0] == 0
        assert (sub / 'module.py').read_text() == 'VALUE = 2\n'
    assert not list(repo.glob('.towarzysz-operator-*'))
