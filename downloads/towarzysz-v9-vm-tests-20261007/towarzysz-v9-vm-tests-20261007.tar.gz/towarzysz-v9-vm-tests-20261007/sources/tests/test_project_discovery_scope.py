"""An explicitly selected repository is scanned as one project."""

from brain.project_discovery import ProjectDiscovery
from brain.observer import Observer
from brain.project_tracker import ProjectTracker


def test_explicit_repo_path_does_not_turn_subdirectories_into_projects(tmp_path):
    repo = tmp_path / 'selected'
    repo.mkdir()
    (repo / '.git').mkdir()
    (repo / 'requirements.txt').write_text('')
    nested = repo / 'nested'
    nested.mkdir()
    (nested / 'module.py').write_text('VALUE = 1\n')

    projects = ProjectDiscovery(scan_paths=[str(repo)])._scan_path(str(repo))
    assert [(project['name'], project['path']) for project in projects] == [
        ('selected', str(repo))]


def test_parent_directory_still_discovers_child_repository(tmp_path):
    repo = tmp_path / 'selected'
    repo.mkdir()
    (repo / '.git').mkdir()
    (repo / 'requirements.txt').write_text('')

    projects = ProjectDiscovery(scan_paths=[str(tmp_path)])._scan_path(str(tmp_path))
    assert [project['path'] for project in projects] == [str(repo)]


def test_selected_project_does_not_read_linked_file_or_runtime_fixtures(tmp_path):
    repo = tmp_path / 'selected'
    repo.mkdir()
    (repo / 'module.py').write_text('VALUE = 1\n')
    outside = tmp_path / 'outside.py'
    outside.write_text('PRIVATE = 1\nPRIVATE = 2\n')
    (repo / 'linked.py').symlink_to(outside)
    fixtures = repo / 'work' / 'validation'
    fixtures.mkdir(parents=True)
    (fixtures / 'generated.py').write_text('GENERATED = 1\n')

    observer = Observer([str(repo)])
    paths = {item['path'] for item in observer.observe()['new_files']}
    assert paths == {'module.py'}
    assert ProjectDiscovery()._count_loc(str(repo)) == 1
    assert ProjectTracker()._get_code_metrics(str(repo))['total_lines'] == 1
