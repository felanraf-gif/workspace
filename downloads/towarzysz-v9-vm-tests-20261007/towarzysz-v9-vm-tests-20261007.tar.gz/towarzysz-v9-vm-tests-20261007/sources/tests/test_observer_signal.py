"""Observer recommendations should refer to real, in-scope files."""

from brain.analyzer import Analyzer
from brain.project_recommender import ProjectRecommender
from brain.roles.architect import Architect
from brain.roles.manager import RoleManager
from brain.roles.scout import Scout


def test_project_analysis_skips_validation_data_and_linked_files(tmp_path):
    repo = tmp_path / 'selected'
    repo.mkdir()
    (repo / 'main.py').write_text('VALUE = 1\n')
    fixture = repo / 'work' / 'validation'
    fixture.mkdir(parents=True)
    (fixture / 'probe.py').write_text('FIXTURE = 2\n')
    outside = tmp_path / 'outside.py'
    outside.write_text('OUTSIDE = 3\n')
    (repo / 'linked.py').symlink_to(outside)

    manager = RoleManager()
    project = manager._prepare_project({'name': 'selected', 'path': str(repo)})
    assert [file['path'] for file in project['files']] == ['main.py']

    scout = Scout(agent_path=str(repo), projects_path=str(tmp_path / 'unused'))
    assert [file['path'] for file in scout._scout_agent()['files']] == ['main.py']

    issues = Analyzer()._analyze_project_deep(project)
    assert not any('probe.py' in str(issue) or 'linked.py' in str(issue)
                   for issue in issues)


def test_unimported_script_is_not_called_dead_code(tmp_path):
    script = tmp_path / 'scripts' / 'verify.py'
    script.parent.mkdir()
    script.write_text('print("standalone")\n')
    main = tmp_path / 'main.py'
    main.write_text('print("start")\n')
    files = [{'name': path.name, 'path': str(path.relative_to(tmp_path)),
              'full_path': str(path)} for path in (main, script)]
    issues = Analyzer()._analyze_project_deep(
        {'name': 'selected', 'path': str(tmp_path), 'files': files})
    assert not any('Martwy kod' in issue['issue'] for issue in issues)


def test_patch_tasks_have_a_specific_target():
    scout = {'findings': {}, 'changes_detected': []}
    issues = [
        {'type': 'dependency', 'priority': 'MEDIUM', 'project': 'selected',
         'issue': 'Nieużywany import', 'suggestions': [
             {'type': 'unused_import', 'file': 'module.py',
              'unused_names': ['helper']}]},
        {'type': 'structure', 'priority': 'MEDIUM', 'project': 'selected',
         'issue': 'Brak pliku głównego'},
    ]
    tasks = Architect().design(scout, {'agent_intel': {'issues': issues},
                                    'project': {'path': '/selected'}})['tasks']
    assert [(task['action'], task['target']) for task in tasks] == [
        ('patch', 'module.py')]


def test_uncommitted_changes_are_for_review_not_urgent_git_action():
    progress = {'name': 'selected', 'status': 'in_progress',
                'git_metrics': {'has_uncommitted': True, 'commits_last_7d': 1},
                'activity_metrics': {'days_since_edit': 0},
                'code_metrics': {'files_count': 1}}
    recommendations = ProjectRecommender()._analyze_project(progress)
    review = [item for item in recommendations if item['type'] == 'action']
    assert len(review) == 1
    assert review[0]['priority'] == 'MEDIUM'
    assert 'git add' not in review[0]['action']
