"""The launcher never starts the agent without a read-only namespace."""

import errno
from pathlib import Path
import sys
from unittest import mock

import pytest

from scripts import observer_sandbox as launcher


def test_command_is_one_cycle_read_only_and_offline(tmp_path, monkeypatch):
    home = tmp_path / 'home'
    home.mkdir()
    repo = home / 'Projects' / 'agent'
    repo.mkdir(parents=True)
    (repo / '.git').mkdir()
    (repo / 'main.py').write_text('')
    (repo / '.env').write_text('SECRET=never-loaded\n')
    python = home / 'Projects' / 'clean' / '.venv' / 'bin' / 'python'
    python.parent.mkdir(parents=True)
    python.symlink_to(sys.executable)
    monkeypatch.setattr(launcher, '_trusted_bwrap', lambda: '/usr/bin/bwrap')
    cmd = launcher.build_command(repo, python, home)
    assert '--unshare-net' in cmd and '--ro-bind' in cmd
    assert cmd[cmd.index('--chdir') + 1] == str(repo)
    assert ['--tmpfs', str(home)] == cmd[cmd.index('--tmpfs'):cmd.index('--tmpfs') + 2]
    assert cmd[-4:] == [str(python), '-B', str(repo / 'main.py'), '--once']
    assert '--clearenv' in cmd
    assert ['--setenv', 'OBSERVER_MODE', 'true'] == cmd[
        cmd.index('OBSERVER_MODE') - 1:cmd.index('OBSERVER_MODE') + 2]
    assert 'AUTHORIZED_REPO' not in cmd
    assert 'TOWARZYSZ_APPROVED_PATCH_SHA256' not in cmd
    assert ['--ro-bind', '/dev/null', str(repo / '.env')] == cmd[
        cmd.index(str(repo / '.env')) - 2:cmd.index(str(repo / '.env')) + 1]


def test_missing_namespace_tool_fails_closed(tmp_path, monkeypatch):
    home = tmp_path / 'home'
    home.mkdir()
    repo = home / 'repo'
    repo.mkdir()
    (repo / '.git').mkdir()
    (repo / 'main.py').write_text('')
    python = home / 'env' / 'bin' / 'python'
    python.parent.mkdir(parents=True)
    python.symlink_to(sys.executable)
    monkeypatch.setattr(launcher, '_trusted_bwrap',
                        lambda: (_ for _ in ()).throw(RuntimeError('missing')))
    with pytest.raises(RuntimeError):
        launcher.build_command(repo, python, home)


def test_probe_accepts_write_denials_but_not_other_io_errors(tmp_path, monkeypatch, capsys):
    home = tmp_path / 'home'
    home.mkdir()
    repo = home / 'repo'
    repo.mkdir()
    (repo / '.git').mkdir()
    (repo / 'main.py').write_text('')
    python = home / 'env' / 'bin' / 'python'
    python.parent.mkdir(parents=True)
    python.symlink_to(sys.executable)
    monkeypatch.setattr(launcher, '_trusted_bwrap', lambda: '/usr/bin/bwrap')
    target = repo / 'denied.txt'
    code = launcher.build_command(repo, python, home, probe_target=target)[-2]
    monkeypatch.setattr(sys, 'argv', ['-c', str(target)])

    for error_code in (errno.EACCES, errno.EPERM, errno.EROFS):
        with mock.patch.object(Path, 'write_text', side_effect=OSError(error_code, 'denied')):
            exec(code, {})
        assert capsys.readouterr().out.strip() == 'OS_WRITE_BLOCKED'

    with mock.patch.object(Path, 'write_text', side_effect=OSError(errno.EIO, 'io error')):
        with pytest.raises(OSError) as error:
            exec(code, {})
    assert error.value.errno == errno.EIO


def test_cloud_workspace_is_hidden_except_selected_repo_and_venv(tmp_path, monkeypatch):
    home = tmp_path / 'home'
    home.mkdir()
    base = tmp_path / 'workspace'
    repo = base / 'repo'
    repo.mkdir(parents=True)
    (repo / '.git').mkdir()
    (repo / 'main.py').write_text('')
    python = repo / '.venv/bin/python'
    python.parent.mkdir(parents=True)
    python.symlink_to(sys.executable)
    monkeypatch.setattr(launcher, '_trusted_bwrap', lambda: '/usr/bin/bwrap')
    cmd = launcher.build_command(repo, python, home, workspace_root=base)
    assert ['--tmpfs', str(base)] == cmd[cmd.index(str(base)) - 1:cmd.index(str(base)) + 1]
    assert ['--tmpfs', str(home)] == cmd[cmd.index(str(home)) - 1:cmd.index(str(home)) + 1]
    assert any(cmd[index:index + 3] == ['--ro-bind', str(repo), str(repo)]
               for index in range(len(cmd) - 2))
    assert '--clearenv' in cmd and '--unshare-net' in cmd
    with pytest.raises(ValueError):
        launcher.build_command(repo, python, home, workspace_root='/')
    with pytest.raises(ValueError):
        launcher.build_command(repo, python, home)  # No implicit cloud override.


@pytest.mark.parametrize('owner,mode', [(65534, 0o755), (1000, 0o755), (0, 0o775)])
def test_untrusted_bwrap_still_fails_closed(tmp_path, monkeypatch, owner, mode):
    tool = tmp_path / 'bwrap'
    tool.write_text('not a trusted system binary')
    monkeypatch.setattr(launcher, 'BWRAP_EXECUTABLE', tool)
    info = mock.Mock(st_mode=0o100000 | mode, st_uid=owner)
    with mock.patch.object(Path, 'stat', return_value=info):
        with pytest.raises(RuntimeError):
            launcher._trusted_bwrap()
