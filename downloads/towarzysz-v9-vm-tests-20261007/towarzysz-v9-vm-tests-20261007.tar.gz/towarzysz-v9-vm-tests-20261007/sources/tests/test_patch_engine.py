"""Controlled patch regressions: no Git execution or permission changes."""
import pytest
from core import observer_policy as policy
from brain.patch_engine import Patch, PatchEngine


@pytest.fixture
def repo(tmp_path, monkeypatch):
    root = tmp_path / 'repo'
    root.mkdir()
    (root / '.git').mkdir()
    monkeypatch.setenv('OBSERVER_MODE', 'false')
    monkeypatch.setattr(policy, '_AUTHORIZATION', policy.RepoAuthorization.from_startup(str(root)))
    engine = PatchEngine()
    engine._project_root = str(root)
    return root, engine


def approve(root, changes, monkeypatch):
    paths = [str(root / change.file) for change in changes]
    monkeypatch.setattr(policy, '_APPROVED_PATCH_DIGEST',
                        policy.patch_fingerprint(root, changes, paths))


def patch(file='test.py', content='VALUE = 2\n', old_code='VALUE = 1\n'):
    return Patch('test', file, 'test patch', old_code, content, confidence=1.0)


def test_outside_root_is_rejected(repo, tmp_path):
    root, engine = repo
    outside = tmp_path / 'outside.py'
    outside.write_text('original')
    assert not engine.apply_patch(patch(str(outside)))
    assert outside.read_text() == 'original'


def test_invalid_python_has_no_side_effects(repo):
    root, engine = repo
    (root / 'test.py').write_text('VALUE = 1\n')
    assert engine.apply_patch(patch(content='def broken(:\n')) is False
    assert (root / 'test.py').read_text() == 'VALUE = 1\n'
    assert not list(root.glob('*.backup.*'))


def test_valid_patch_is_verified_without_git(repo, monkeypatch):
    import subprocess
    root, engine = repo
    (root / 'test.py').write_text('VALUE = 1\n')
    monkeypatch.setattr(subprocess, 'run', lambda *a, **k: pytest.fail('Git was executed'))
    change = patch()
    approve(root, [change], monkeypatch)
    assert engine.apply_patch(change) is True
    assert (root / 'test.py').read_text() == 'VALUE = 2\n'
    assert change.applied
    assert engine.rollback(change) is False  # Manual rollback requires separate review.
    assert (root / 'test.py').read_text() == 'VALUE = 2\n'


def test_new_file_removed_on_verification_failure(repo, monkeypatch):
    root, engine = repo
    monkeypatch.setattr(engine, 'verify_patch', lambda p: (False, 'forced verification failure'))
    change = patch(old_code=None)
    approve(root, [change], monkeypatch)
    assert engine.apply_patch(change) is False
    assert not (root / 'test.py').exists()


def test_batch_preflight_blocks_all_writes_on_outside_target(repo, tmp_path):
    root, engine = repo
    assert engine.apply_patches([patch(old_code=None), patch(str(tmp_path / 'outside.py'), old_code=None)]) == []
    assert not (root / 'test.py').exists()


def test_multiple_valid_patches_do_not_commit(repo, monkeypatch):
    import subprocess
    root, engine = repo
    monkeypatch.setattr(subprocess, 'run', lambda *a, **k: pytest.fail('Git was executed'))
    changes = [patch(old_code=None), patch('second.py', old_code=None)]
    approve(root, changes, monkeypatch)
    assert len(engine.apply_patches(changes)) == 2
    assert (root / 'test.py').read_text() == 'VALUE = 2\n'
    assert (root / 'second.py').read_text() == 'VALUE = 2\n'
    assert list((root / '.git').iterdir()) == []


def test_multiple_patches_roll_back_on_late_failure(repo, monkeypatch):
    root, engine = repo
    (root / 'test.py').write_text('VALUE = 1\n')
    original = engine.verify_patch
    monkeypatch.setattr(engine, 'verify_patch', lambda p: (False, 'forced') if p.file == 'second.py' else original(p))
    changes = [patch(), patch('second.py', old_code=None)]
    approve(root, changes, monkeypatch)
    assert engine.apply_patches(changes) == []
    assert (root / 'test.py').read_text() == 'VALUE = 1\n'
    assert not (root / 'second.py').exists()


def test_rollback_outside_authority_is_denied(repo, tmp_path):
    root, engine = repo
    outside = tmp_path / 'outside'
    outside.write_text('original')
    change = patch(str(outside))
    assert engine.rollback(change) is False
    assert outside.read_text() == 'original'


def test_explicit_no_confirmation_never_writes(repo):
    root, engine = repo
    target = root / 'test.py'
    target.write_text('VALUE = 1\n')
    assert not engine.apply_patches([patch()], auto_confirm=False)
    assert target.read_text() == 'VALUE = 1\n'
    assert not list(root.glob('*.backup.*'))


def test_stale_second_patch_rejects_batch_without_side_effects(repo, monkeypatch):
    root, engine = repo
    first = root / 'test.py'
    second = root / 'second.py'
    first.write_text('VALUE = 1\n')
    second.write_text('VALUE = 1\n')

    changes = [patch(), patch('second.py')]
    approve(root, changes, monkeypatch)
    second.write_text('VALUE = 99\n')

    result = engine.apply_patches(changes)

    assert first.read_text() == 'VALUE = 1\n'
    assert second.read_text() == 'VALUE = 99\n'
    assert result == []
    assert not list(root.rglob('*.backup.*'))
    assert not engine.applied_patches
    assert all(not change.applied for change in changes)
    assert policy._APPROVED_PATCH_DIGEST is None


def test_approved_scope_cannot_write_other_file_or_survive_attempt(repo, monkeypatch):
    root, _ = repo
    target = root / 'test.py'
    other = root / 'other.py'
    target.write_text('VALUE = 1\n')
    other.write_text('KEEP = 1\n')
    change = patch()
    approve(root, [change], monkeypatch)
    with policy.approved_patch_scope(root, [change], [str(target)]) as approved:
        assert approved
        with pytest.raises(PermissionError):
            with policy.scoped_open(other, 'w'):
                pass
    with pytest.raises(PermissionError):
        with policy.scoped_open(target, 'w'):
            pass
    assert target.read_text() == 'VALUE = 1\n'
    assert other.read_text() == 'KEEP = 1\n'

def test_preflight_rejects_missing_expected_file(repo):
    root, engine = repo
    first = root / 'test.py'
    first.write_text('VALUE = 1\n')
    assert engine.apply_patches([patch(), patch('missing.py')]) == []
    assert first.read_text() == 'VALUE = 1\n'
    assert not list(root.rglob('*.backup.*'))

def test_preflight_rejects_existing_new_file(repo):
    root, engine = repo
    first = root / 'test.py'
    first.write_text('VALUE = 1\n')
    second = root / 'second.py'
    second.write_text('VALUE = 99\n')
    assert engine.apply_patches([patch(), patch('second.py', old_code=None)]) == []
    assert first.read_text() == 'VALUE = 1\n'
    assert second.read_text() == 'VALUE = 99\n'
    assert not list(root.rglob('*.backup.*'))


def test_patch_without_explicit_approval_is_rejected(repo):
    root, engine = repo
    target = root / 'test.py'
    target.write_text('VALUE = 1\n')
    assert engine.apply_patches([patch()], auto_confirm=True) == []
    assert target.read_text() == 'VALUE = 1\n'
    assert not list(root.rglob('*.backup.*'))


def test_approved_patch_mutation_is_rejected(repo, monkeypatch):
    root, engine = repo
    target = root / 'test.py'
    target.write_text('VALUE = 1\n')
    change = patch()
    approve(root, [change], monkeypatch)
    change.new_code = 'VALUE = 3\n'
    assert engine.apply_patches([change]) == []
    assert target.read_text() == 'VALUE = 1\n'
    assert not list(root.rglob('*.backup.*'))

def test_late_environment_change_cannot_grant_patch_approval(repo, monkeypatch):
    root, engine = repo
    target = root / 'test.py'
    target.write_text('VALUE = 1\n')
    change = patch()
    paths = [str(target)]
    monkeypatch.setattr(policy, '_APPROVED_PATCH_DIGEST', None)
    monkeypatch.setenv('TOWARZYSZ_APPROVED_PATCH_SHA256',
                       policy.patch_fingerprint(root, [change], paths))
    assert engine.apply_patches([change]) == []
    assert target.read_text() == 'VALUE = 1\n'


def test_approval_cannot_be_reused_after_rollback(repo, monkeypatch):
    root, engine = repo
    target = root / 'test.py'
    target.write_text('VALUE = 1\n')
    change = patch()
    approve(root, [change], monkeypatch)
    assert engine.apply_patch(change) is True
    assert engine.rollback(change) is False
    assert target.read_text() == 'VALUE = 2\n'
    assert engine.apply_patch(patch()) is False
    assert target.read_text() == 'VALUE = 2\n'


def test_approved_patch_content_cannot_change_after_approval(repo, monkeypatch):
    """Only content covered by the consumed approval may reach disk."""
    import ast

    root, engine = repo
    target = root / 'test.py'
    target.write_text('VALUE = 1\n')

    change = patch()
    approved_code = change.new_code
    approve(root, [change], monkeypatch)

    real_parse = ast.parse
    mutation_happened = False

    def mutate_after_approval(source, *args, **kwargs):
        nonlocal mutation_happened
        # apply_patches() has already consumed the human approval
        # before it reaches syntax validation.
        assert policy._APPROVED_PATCH_DIGEST is None
        mutation_happened = True
        change.new_code = 'VALUE = 999\n'
        return real_parse(source, *args, **kwargs)

    monkeypatch.setattr(ast, 'parse', mutate_after_approval)

    engine.apply_patches([change])

    assert mutation_happened
    assert target.read_text() in {'VALUE = 1\n', approved_code}
    assert target.read_text() != 'VALUE = 999\n'
