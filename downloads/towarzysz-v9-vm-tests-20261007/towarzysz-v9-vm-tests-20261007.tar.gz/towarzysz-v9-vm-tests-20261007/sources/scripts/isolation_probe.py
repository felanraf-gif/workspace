"""Non-destructive OS access probe. Run only under the reviewed test unit."""

import errno
import grp
import os
import pwd
import socket
import sys

ROOT = '/home/felanraf/Projekty/towarzysz-v9-audit-20260925'
TARGETS = (
    ROOT + '/main.py',
    '/opt/towarzysz-agent/scripts/isolation_probe.py',
)


def denied_open(path, flags):
    try:
        fd = os.open(path, flags | os.O_NOFOLLOW)
    except OSError as exc:
        return exc.errno in (errno.EACCES, errno.EPERM, errno.EROFS, errno.ENOENT)
    else:
        os.close(fd)
        return False


def main():
    outcomes = {}
    try:
        forbidden_group = grp.getgrnam('felanraf').gr_gid
        expected_uid = pwd.getpwnam('towarzysz-agent').pw_uid
    except KeyError:
        print('STOP: konto próbne lub grupa operatora nie istnieje')
        return 2
    outcomes['właściwe konto agenta'] = os.geteuid() == expected_uid
    outcomes['bez grupy felanraf'] = forbidden_group not in os.getgroups()
    outcomes['repo nieczytelne bez czytnika'] = denied_open(TARGETS[0], os.O_RDONLY)
    outcomes['repo nieotwieralne do zapisu'] = denied_open(TARGETS[0], os.O_WRONLY)
    outcomes['kod agenta nieotwieralny do zapisu'] = denied_open(TARGETS[1], os.O_WRONLY)
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except OSError:
        outcomes['gniazdo internetowe zablokowane'] = True
    else:
        sock.close()
        outcomes['gniazdo internetowe zablokowane'] = False
    state_path = os.environ.get('STATE_DIRECTORY')
    if state_path and os.path.isdir(state_path):
        outcomes['własny stan dostępny'] = os.access(state_path, os.W_OK)
    else:
        outcomes['własny stan dostępny'] = False
    for label, passed in outcomes.items():
        print(('PASS' if passed else 'FAIL') + ': ' + label)
    return 0 if all(outcomes.values()) else 1


if __name__ == '__main__':
    sys.exit(main())
