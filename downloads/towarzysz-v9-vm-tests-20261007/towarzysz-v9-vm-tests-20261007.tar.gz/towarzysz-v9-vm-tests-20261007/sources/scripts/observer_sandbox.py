"""Run one Observer cycle with OS-enforced, read-only host mounts and no network.

Requires working bubblewrap user namespaces. If sandbox setup fails, Towarzysz
does not start. This launcher never enables the application execution mode.
"""

import argparse
import os
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

BWRAP_EXECUTABLE = Path('/usr/bin/bwrap')


def _trusted_bwrap():
    try:
        info = BWRAP_EXECUTABLE.stat()
    except OSError as exc:
        raise RuntimeError('Brak systemowego bubblewrap; nie uruchomiono Towarzysza') from exc
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or
            stat.S_IMODE(info.st_mode) & 0o022):
        raise RuntimeError('Bubblewrap nie ma bezpiecznego właściciela lub trybu')
    return str(BWRAP_EXECUTABLE)


def _workspace(home, workspace_root):
    base = Path(home if workspace_root is None else workspace_root)
    if (not base.is_absolute() or base.is_symlink() or
            base != base.resolve(strict=True) or not base.is_dir() or
            base == Path('/')):
        raise ValueError('Wskaż rzeczywisty katalog roboczy, inny niż /')
    return base


def _paths(repo, python, home, workspace_root=None):
    root = Path(repo)
    interpreter = Path(python)
    if (not root.is_absolute() or root.is_symlink() or
            root != root.resolve(strict=True) or
            not root.is_dir() or not (root / '.git').is_dir() or
            not (root / 'main.py').is_file()):
        raise ValueError('Wskaż rzeczywisty katalog repozytorium Towarzysza')
    if (not interpreter.is_absolute() or not interpreter.is_file() or
            not os.access(interpreter, os.X_OK)):
        raise ValueError('Wskaż działający interpreter z venv')
    environment = interpreter.parent.parent
    base = _workspace(home, workspace_root)
    if (root == base or environment == base or not root.is_relative_to(base) or
            not environment.is_relative_to(base)):
        raise ValueError('Repozytorium i venv muszą leżeć we wskazanym katalogu roboczym')
    return root, interpreter, environment


def build_command(repo, python, home, *, probe_target=None, workspace_root=None):
    """Build fixed bubblewrap arguments; no arbitrary agent-supplied flags."""
    root, interpreter, environment = _paths(repo, python, home, workspace_root)
    bwrap = _trusted_bwrap()
    home = Path(home)
    base = _workspace(home, workspace_root)
    parents = set()
    for item in (root, environment):
        current = item.parent
        while current != base:
            if not current.is_relative_to(base):
                raise ValueError('Nieprawidłowy katalog nadrzędny')
            parents.add(current)
            current = current.parent
    command = [bwrap, '--die-with-parent', '--new-session',
               '--unshare-user', '--unshare-pid', '--unshare-net',
               '--unshare-ipc', '--unshare-uts',
               '--ro-bind', '/', '/', '--tmpfs', str(base)]
    # Hide the actual home as well as unrelated cloud workspace checkouts.
    # A home nested inside base is already hidden by the base tmpfs.
    if home != base and not home.is_relative_to(base):
        command += ['--tmpfs', str(home)]
    for parent in sorted(parents, key=lambda path: (len(path.parts), str(path))):
        command += ['--dir', str(parent)]
    for source in (root, environment):
        command += ['--ro-bind', str(source), str(source)]
    dotenv = root / '.env'
    if dotenv.exists() or dotenv.is_symlink():
        info = dotenv.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError('Nie można bezpiecznie ukryć pliku .env')
        command += ['--ro-bind', '/dev/null', str(dotenv)]
    command += ['--tmpfs', '/run', '--tmpfs', '/tmp',
                '--proc', '/proc', '--dev', '/dev', '--chdir', str(root),
                '--clearenv']
    settings = {
        'HOME': str(home), 'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8',
        'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1',
        'OBSERVER_MODE': 'true', 'INTEGRATE_OBSIDIAN': 'false',
        'INTEGRATE_TODOIST': 'false',
        'WORKSPACE_PATH': str(root), 'PROJECT_SCAN_PATHS': str(root),
        'AGENT_CODE_PATH': str(root),
        'MEMORY_PATH': str(root / 'work/observer-sandbox/memory'),
        'SYSTEM_PATH': str(root / 'work/observer-sandbox/system'),
        'OBSIDIAN_PATH': str(root / 'work/observer-sandbox/obsidian'),
        'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null',
        'GIT_TERMINAL_PROMPT': '0',
    }
    for key, value in settings.items():
        command += ['--setenv', key, value]
    if probe_target is None:
        return command + ['--', str(interpreter), '-B', str(root / 'main.py'), '--once']
    # The probe is only run in a temporary, operator-created directory.
    code = ("import errno, sys\nfrom pathlib import Path\n"
            "try:\n    Path(sys.argv[1]).write_text('probe')\n"
            "except OSError as exc:\n"
            "    if exc.errno not in (errno.EACCES, errno.EPERM, errno.EROFS):\n"
            "        raise\n"
            "    print('OS_WRITE_BLOCKED')\n"
            "else:\n    print('ISOLATION_FAILED')\n    sys.exit(1)\n")
    return command + ['--', str(interpreter), '-B', '-c', code, str(probe_target)]


def main(argv=None):
    parser = argparse.ArgumentParser(description='Jeden odczytowy cykl Towarzysza')
    parser.add_argument('--repo', required=True)
    parser.add_argument('--python', required=True, help='Absolutna ścieżka do Python z venv')
    parser.add_argument('--workspace-root', help='Jawny katalog repo i venv, np. /workspace; domyślnie HOME')
    parser.add_argument('--probe', action='store_true', help='Sprawdź blokadę zapisu; nie uruchamiaj agenta')
    args = parser.parse_args(argv)
    try:
        root, interpreter, _ = _paths(args.repo, args.python, Path.home().resolve(),
                                      args.workspace_root)
        if args.probe:
            with tempfile.TemporaryDirectory(prefix='sandbox-probe-', dir=root) as directory:
                command = build_command(root, interpreter, Path.home().resolve(),
                                        probe_target=Path(directory) / 'denied.txt',
                                        workspace_root=args.workspace_root)
                result = subprocess.run(command, capture_output=True, text=True, timeout=30)
                if result.returncode or result.stdout.strip() != 'OS_WRITE_BLOCKED':
                    print('Izolacja niedostępna: ' + (result.stderr.strip() or result.stdout.strip()),
                          file=sys.stderr)
                    return 1
            print('OK: system operacyjny zablokował zapis w repozytorium.')
            return 0
        command = build_command(root, interpreter, Path.home().resolve(),
                                workspace_root=args.workspace_root)
        return subprocess.run(command, timeout=180).returncode
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f'Nie uruchomiono Towarzysza: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
