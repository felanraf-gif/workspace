"""Read-only baseline for proposed OS separation. Never modifies accounts or units."""

import argparse
import grp
import os
import pwd
import stat
import subprocess
from pathlib import Path


def inspect(service, repo):
    command = ['systemctl', 'show', service]
    for field in ('LoadState', 'User', 'Group', 'ActiveState', 'WorkingDirectory', 'FragmentPath'):
        command.extend(('-p', field))
    result = subprocess.run(command, capture_output=True, text=True, timeout=5)
    if result.returncode:
        raise RuntimeError('Nie można odczytać stanu usługi')
    props = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
    if props.get('LoadState') != 'loaded':
        raise RuntimeError('Jednostka usługi nie jest załadowana lub jest nieznana')
    rows = [f"Usługa: {service}", f"Stan: {props.get('ActiveState', '?')}",
            f"Konto usługi: {props.get('User', '?')}",
            f"Katalog roboczy: {props.get('WorkingDirectory', '?')}",
            f"Plik jednostki: {props.get('FragmentPath', '?')}"]
    try:
        agent = pwd.getpwnam('towarzysz-agent')
    except KeyError:
        rows.append('Konto towarzysz-agent: brak')
        agent = None
    if agent:
        groups = {group.gr_gid: group.gr_name for group in grp.getgrall()}
        member_groups = {groups.get(gid, str(gid)) for gid in os.getgrouplist(agent.pw_name, agent.pw_gid)}
        rows.append('Konto towarzysz-agent: istnieje')
        rows.append('Grupa felanraf przy agencie: ' + ('TAK' if 'felanraf' in member_groups else 'nie'))
    for name, path in [('HOME operatora', Path.home()), ('Repo audytowe', Path(repo))]:
        try:
            info = path.stat()
        except OSError:
            rows.append(f'{name}: niedostępne ({path})')
            continue
        rows.append(f'{name}: {pwd.getpwuid(info.st_uid).pw_name} {stat.S_IMODE(info.st_mode):03o} {path}')
    ready = (props.get('ActiveState') == 'inactive' and props.get('User') == 'towarzysz-agent'
             and agent is not None and 'felanraf' not in member_groups)
    rows.append('Izolacja konta w jednostce: ' + ('KANDYDAT do testów' if ready else 'NIEWDROŻONA'))
    rows.append('Ten odczyt nie potwierdza praw dostępu ani blokady sieci; potrzebne testy negatywne.')
    return '\n'.join(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', help='ścieżka repozytorium audytowego')
    parser.add_argument('--service', default='towarzysz.service')
    args = parser.parse_args()
    try:
        print(inspect(args.service, args.repo))
    except (OSError, RuntimeError, ValueError) as exc:
        print(f'Nie udało się odczytać konfiguracji: {exc}')
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
