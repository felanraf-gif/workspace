# Towarzysz V9 — plan izolacji kont i kontrolera (do zatwierdzenia)

> **Wariant historyczny, nieobowiązujący (26.09.2026).** Rafał zdecydował
> o pracy na jednym koncie `felanraf`; poniższy plan osobnego konta i sonda
> `deploy/towarzysz-isolation-probe.service` nie są przeznaczone do instalacji.
> Jedno UID nie daje granicy uprawnień OS między agentem i operatorem.
> Bieżąca bezpieczna ścieżka to jednorazowy Observer Mode bez zgody na zapis.

**Data:** 25.09.2026. **Status:** projekt instalacji, bez zmian na laptopie.
Dotyczy istniejącego klonu audytowego; nie podmienia działającej jednostki.

## Fakty wejściowe

- `towarzysz.service` jest wyłączona i nieaktywna; wskazuje `User=felanraf`
  oraz stary katalog `/home/felanraf/Projekty/workspace`.
- `/home/felanraf` ma tryb 750, a repo audytowe i aktywne pliki kodu należą
  do `felanraf:felanraf`. Brak konta i grupy `towarzysz-agent`.
- Bramka PatchEngine jest w procesie agenta. Direct FileTools zapis był
  możliwy bez zgody; częściowa poprawka w kopii zamyka tę drogę, ale sonda
  nadal potwierdza zapis przez `observer_storage.open` przy aktywnej R1.
- Lokalny prototyp `cli/proposal_review.py` niczego nie zatwierdza naprawdę.
  Testy aplikacji nie dowodzą separacji kont.

## Rozmieszczenie docelowe

| Składnik | Miejsce / tożsamość | Prawo agenta |
| --- | --- | --- |
| Kod wykonywany przez agenta | osobna instalacja `/opt/towarzysz-agent/`, właściciel `felanraf` | tylko odczyt/uruchomienie; konto agenta nie jest właścicielem ani członkiem grupy dającej zapis |
| Proces agenta | `User=towarzysz-agent`, bez grupy `felanraf`, bez uprawnień administratora | wyłącznie dopuszczone operacje analityczne i publikacja propozycji |
| Stan własny agenta | `/var/lib/towarzysz-agent/`, osobny od repozytoriów | tylko własne pliki stanu, bez prawa zapisu w projektach |
| Proces kontrolera | `felanraf`, uruchamiany świadomie i odrębnie | dostęp do plików wybranych przez Rafała; agent nie modyfikuje jego kodu ani decyzji |
| Kod i prywatny stan kontrolera | własność `felanraf`, katalog pod `/home/felanraf/` nieosiągalny dla konta agenta | brak odczytu i zapisu; również brak dostępu do kluczy i poświadczeń |
| Kanał propozycji | lokalne gniazdo IPC utworzone poza katalogami zapisywalnymi przez agenta | może wysłać niezaufaną propozycję; nie może czytać decyzji, tworzyć socketu ani zmieniać jego konfiguracji |
| Czytnik projektów i chmury | osobny komponent kontrolowany przez operatora | agent nie otrzymuje poświadczeń ani pełnych kopii źródeł; sposób udostępnienia danych do analizy jest osobnym projektem |

Nie dodawać `towarzysz-agent` do grupy `felanraf`, nie otwierać całego HOME
uprawnieniami dla wszystkich i nie montować całego katalogu domowego do
usługi. Szeroki odczyt oraz porównanie danych chmurowych mają być możliwe
przez kontrolowaną, prywatną analizę; dokładny mechanizm nie jest jeszcze
wybrany. Separacja procesu nie pozwala udawać, że konto agenta samo może
bezpiecznie czytać wszystkie pliki użytkownika.

Rafał pozostaje właścicielem kodu, repozytoriów, kontrolera i prywatnych
danych; ma kontrolę administracyjną nad całością. Oddzielne konto służy
wyłącznie ograniczeniu tego, co **proces** Towarzysza może zrobić bez jego
udziału. Plik jednostki pod `/etc/systemd/system/` pozostaje plikiem
systemowym zarządzanym przez administratora. Roboczy stan w `/var/lib/`
może wymagać technicznej własności konta agenta, jeśli ma ono samo go
zapisywać; to wyjątek dotyczący generowanego stanu, nie przeniesienie
własności istniejących plików Rafała. Możliwy wariant stanu należącego do
Rafała z zapisem przez pośrednika wymaga osobnego projektu. Żaden wariant
nie zmienia właściciela plików w Twoich projektach.

## Kanał i decyzja

Agent przekazuje wyłącznie propozycję jako dane. Kontroler odczytuje ją do
własnej pamięci, limituje rozmiar/częstotliwość, sprawdza pochodzenie procesu,
ścieżki, dowody i aktualny stan źródła; diff wylicza sam. Kanał nie zawiera
funkcji „zatwierdź”. Po Twojej decyzji kontroler zapisuje prywatny ślad,
ponownie sprawdza stan i ewentualnie uruchamia dokładnie zatwierdzony zapis.
Osobne dzienniki i backupy nie mogą ujawniać sekretów. Błąd lub zawieszenie
kontrolera oznacza STOP, nie zgodę przez domyślność.

Zanim wdrożymy IPC, potwierdzić zgodność socket activation lub innej metody
z systemd 255 na laptopie. Użycie samego `IPAddressDeny=` nie jest dowodem
braku wyjścia do sieci; konieczna jest próba negatywna w faktycznie działającej
jednostce i kontrola innych kanałów. Czytnik chmurowy wymaga ściśle
ograniczonego dostępu do wskazanych kont; bez tego pozostaje wyłączony.

## Kolejność zmian i warunki przejścia

**Przygotowany przykład do przeglądu:** `deploy/towarzysz-isolation-probe.service`
uruchamia wyłącznie `scripts/isolation_probe.py` jako przyszłe konto agenta.
Nie startuje `main.py`, nie dotyka obecnej usługi, nie ma sekcji `[Install]`
i po uruchomieniu kończy się. Zakłada wcześniejszą instalację kopii sondy
w chronionej `/opt/towarzysz-agent/scripts/` oraz utworzenie konta i
oddzielnego stanu. Próba otwiera istniejący plik projektu i kod sondy w
trybie do zapisu **bez obcinania i bez zapisu bajtów**; jeśli otwarcie się
powiedzie, oznacza FAIL. Testuje także brak bezpośredniego odczytu HOME,
brak grupy operatora, blokadę tworzenia gniazda internetowego i dostęp do
własnego stanu. Przed uruchomieniem sprawdzić, że obie ścieżki istnieją.
Poza gniazdem internetowym trzeba osobno sprawdzić Unix sockety, odziedziczone
deskryptory i lokalne pośredniki sieciowe; PASS sondy nie oznacza pełnej
izolacji. Unit i probe są szablonami, nie wdrożeniem.

1. **Zachowanie stanu:** odczytać rzeczywistą jednostkę i grupy, wykaz
   zależności, potwierdzić nieaktywność usługi, porównać z backupem. Bez
   przełączania starej jednostki.
2. **Projekt testowy:** instalacja kopii kodu, konto próbne i prywatne katalogi
   tylko po osobnej zgodzie na konkretne działania administracyjne. Na
   początku uruchamiać jednorazowe testy, bez auto-startu i bez dostępu do
   rzeczywistych projektów lub chmury.
3. **Negatywne testy OS:** jako konto agenta nie da się zmienić plików projektu,
   `.git`, kodu i konfiguracji kontrolera, decyzji, usługi, repo źródłowego,
   cudzych katalogów ani uzyskać poświadczeń. Sprawdzić nieudane próby zapisu,
   uruchomienia polecenia i dostępu do sieci, a nie tylko deklarowane opcje.
4. **Test kontrolera:** fałszywa propozycja i prawdziwa propozycja z repo
   testowego; odmowa, poprawa, zmiana pliku po zgodzie, ponowne użycie
   decyzji, awaria, rollback i raport. Brak zapisu bez jawnej decyzji.
5. **Dopiero po PASS:** rozstrzygnąć dostęp do danych, źródła chmurowe i
   wdrożenie nowej usługi. Zachować starą jednostkę wyłączoną do osobnej
   decyzji o migracji. Po zakończeniu porównać stan OS/Git z wejściowym.

## Kryteria STOP i odtworzenie

Nie przechodzić do następnego etapu przy choć jednej udanej próbie zapisu
z konta agenta do projektu lub kontrolera, dostępie do kluczy, nieznanym
ruchu sieciowym, niepełnym diffie albo niespójnym stanie po awarii. Przy
niepowodzeniu wyłączyć nową jednostkę testową, wrócić do zachowanej
konfiguracji i porównać pliki oraz uprawnienia z zapisem wejściowym.
Usuwanie kont, katalogów i backupów wymaga osobnej decyzji, a nie automatycznego
sprzątania.

## Czynności wymagające osobnej zgody przed wykonaniem

- Utworzenie konta/grupy i katalogów poza repozytorium.
- Zmiana właścicieli/uprawnień lub instalacja plików do `/opt` i `/var/lib`.
- Utworzenie/zmiana jednostek systemd, socketu i zasad sieciowych.
- Przyznanie dostępu do projektów, chmury lub poświadczeń czytnikowi.
- Start nowej usługi albo zmiana obecnej; każdy commit i push.

**Najbliższa czynność bez podwyższenia uprawnień:** odczytać aktualny plik
jednostki i jej zależności, po czym przygotować dokładny diff przyszłej
konfiguracji testowej do oceny Rafała.
