# Towarzysz V9 — projekt struktury dalszych zmian

> **Projekt historyczny (25.09.2026).** Opis osobnego konta agenta poniżej
> zastąpiła decyzja Rafała z 26.09.2026: agent działa na jednym koncie
> `felanraf`. Role i interfejs w tym dokumencie są wymaganiami projektowymi,
> nie wdrożoną granicą bezpieczeństwa. Na jednym UID nie można odizolować
> procesu przed zapisem do plików użytkownika samą polityką Pythona.
> Do czasu sprawdzenia niezależnej kontroli zgody tryb wykonawczy pozostaje
> wyłączony; plan osobnego konta oraz sonda systemd nie obowiązują.

**Stan:** propozycja do wspólnego przeglądu, 25.09.2026. **Zakres:** lokalny agent
obserwujący system i projekty, przygotowujący propozycje zmian oraz wykonujący
tylko działania zaakceptowane przez Rafała w niezależnym kontrolerze.
Nie jest to opis już wdrożonych zabezpieczeń ani zgoda na zmianę usługi.

## 1. Cel i miara użyteczności

Towarzysz ma pomagać w codziennej pracy: obserwować projekty i wybrane sygnały
systemowe, śledzić zadania, wykrywać problemy, ustalać priorytety, wyjaśniać
wnioski, przygotowywać propozycje napraw oraz **wykonywać zaakceptowaną,
ostateczną wersję** przez odrębnego wykonawcę z ograniczonymi uprawnieniami.
Człowiek decyduje, czy zmianę przyjąć, poprawić czy odrzucić. Godny zaufania wynik oznacza jednocześnie:
trafne obserwacje, zrozumiały zakres, brak nieautoryzowanych skutków, możliwość
przerwania działania i ślad pozwalający sprawdzić, co się wydarzyło.

Priorytet HIGH oznacza pilność powiadomienia, **nie** prawo do wykonania.
Wszystkie zapisy w projektach wymagają konkretnej decyzji człowieka niezależnie
od priorytetu, pewności modelu i rodzaju poprawki. Brak decyzji oznacza odmowę.

**Reguła danych:** Towarzysz może odczytać dane z urządzeń Rafała i jego kont
chmurowych oraz porównywać je w kontrolowanym, prywatnym kontekście analizy.
Taki odczyt nie upoważnia do eksportu, synchronizacji, publikacji, trwałego
kopiowania, zapisu u innego dostawcy ani zmiany u źródła. Podgląd
wyniku przez Rafała nie jest zgodą na dalsze użycie lub eksport. Dotyczy to
także metadanych (nazw plików, adresów, identyfikatorów), fragmentów kodu,
logów, zrzutów ekranu, treści schowka, wyników analizy oraz danych pochodnych.
Samo podłączenie konta, dostęp do odczytu, wysoki priorytet albo decyzja o
lokalnej poprawce nie jest zgodą na przekazanie danych. Zasada obejmuje także
telemetrię, zgłoszenia błędów, zdalne LLM, synchronizację, repozytoria Git,
Notion i inne integracje; każdy kanał należy ocenić osobno.

**Granica przestrzeni (doprecyzowana przez Rafała):** ochronie podlega każde
miejsce, w którym znajdują się jego dane: urządzenie, konto, repozytorium,
projekt, wydzielony katalog i przestrzeń chmurowa. Wyjątkiem koniecznym do
porównania źródeł jest kontrolowany odczyt do prywatnego kontekstu analizy:
może czasowo przenieść potrzebne dane z chmury lub innego urządzenia, lecz
nie tworzy ogólnej zgody na eksport, utrwalanie kopii ani przesyłanie dalej.
Kopie w pamięci i wyniki porównań są równie prywatne jak źródła; granice ich
przechowywania, czasu życia i dostępu muszą być zdefiniowane i testowane.
Dokładne techniczne granice projektu i katalogu należy zmapować przed
udzieleniem dostępu. Nie twierdzimy, że obecny kod już zapewnia tę izolację.

**Decyzja Rafała (25.09.2026):** dalszy eksport danych jest dopuszczalny wyłącznie
pod jego nadzorem i za zgodą na konkretną treść, cel oraz odbiorcę. Nie ma
zgody stałej na automatyczny eksport, synchronizację ani wysyłanie danych
przez Towarzysza. Do czasu wdrożenia i sprawdzenia niezależnego kontrolera
Towarzysz nie wykonuje eksportu; Rafał może wykonać go ręcznie poza agentem.

**Decyzja o odczycie (doprecyzowana przez Rafała):** Towarzysz może szukać
rozwiązania problemu we wszystkich jego plikach, również chmurowych, bo
przydatna informacja może znajdować się poza bieżącym projektem. Może
zestawiać dane z różnych źródeł, aby usprawniać pracę i wykrywać problemy.
Odczyt służy prywatnej analizie i przedstawieniu wniosków Rafałowi; nie
udziela prawa do dalszego eksportu, trwałego kopiowania, zmiany, użycia w
zewnętrznym modelu ani ujawnienia sekretu w logu lub propozycji. Nie
obiecujemy odczytu zasobów, do których system nie ma jeszcze bezpiecznej,
jawnie udzielonej ścieżki dostępu; nie przejmujemy poświadczeń.
Zaufanie wymaga widocznego zakresu odczytu i celu analizy, przeglądalnego
dziennika dostępu bez kopiowania treści oraz prostego wyłączenia dostępu
przez Rafała. Samo istnienie szerokiego odczytu nie uprawnia do cichego
skanowania kont lub używania danych w innym zadaniu.

**Zasada wspólnej decyzji o strukturze:** Towarzysz może wskazać, co warto
zmienić lub dodać w układzie projektu, opisać powód, spodziewany wpływ i
konkretne pliki, po czym zatrzymuje się. Dodanie, usunięcie, przeniesienie
albo zmiana nazw plików/katalogów, zależności, konfiguracji, struktury Git
czy sposobu uruchamiania wymaga odrębnego omówienia i decyzji Rafała o
zakresie. Poprawka tekstowa nie rozszerza tej zgody na przebudowę projektu.

## 2. Fakty potwierdzone na tym etapie

- Na laptopie: gałąź `audit/towarzysz-v9-2026-09-25` w niezależnym klonie,
  lokalny commit `3068b49` przed gałęzią zdalną, dziewięć zmodyfikowanych
  plików po poprawkach zgód i komunikatów. Ostatni przekazany wynik z laptopa:
  **105 passed, 1 deselected**; `git diff --check` bez błędów. Nie potwierdzono
  jeszcze testów laptopa po dodaniu prototypu interfejsu.
- W kopii roboczej prototypu: **109 passed, 1 deselected**. Pominięty jest
  historyczny test używający `chmod`; wynik nie dowodzi bezpieczeństwa całego OS.
- `OBSERVER_MODE` blokuje kontrolowane wykonawcze skutki; R1 ogranicza
  kontrolowane zapisy do jednego repozytorium ze środowiska startowego.
- Odcisk patcha związany z zakresem i treścią jest jednorazowy, lecz sprawdza
  go tylko PatchEngine. Potwierdzona droga `FileTools.write()` nie wymaga tego
  odcisku. Odcisk dostępny temu samemu procesowi nie jest niezależną zgodą.
- Usługa `towarzysz.service` jest nieaktywna i wyłączona. Jej konfiguracja
  wskazuje konto `felanraf` oraz stary katalog `~/Projekty/workspace`.
  Pliki aktywnego kodu i repozytorium należą do tego samego konta/grupy.
- Wersja terminalowa `cli/proposal_review.py` prezentuje pełny diff i trzy
  wybory. Jest prototypem podglądu: **nie wykonuje, nie zapisuje decyzji i
  nie udziela uprawnień**.
- Istnieje zweryfikowana kopia lokalna historycznego stanu, ale może zawierać
  sekrety. Nie wolno jej publikować. Dokumenty V4 w korzeniu są historyczne;
  mogą mylić z aktualną dokumentacją V9.

## 3. Granice ról i przepływ

| Rola | Może | Nie może |
| --- | --- | --- |
| Agent (osobne, ograniczone konto OS) | Odczytywać dopuszczone obserwacje, proponować zmianę, podawać pilność i dowody, koordynować zatwierdzoną pracę i raportować jej skutek | Pisać bezpośrednio w projektach, `.git`, kontrolerze, kodzie polityki, kluczach i kanale decyzji; uruchamiać dowolny shell/Python |
| Kanał propozycji | Przyjmować dane od agenta jako **niezaufane** | Interpretować dane jako zgodę lub polecenie wykonania |
| Kontroler operatora | Weryfikować źródło i zakres, pokazać pełny diff, odebrać decyzję | Ufać ścieżkom, priorytetom i kodowi dostarczonym przez agenta bez sprawdzenia |
| Wykonawca Towarzysza pod kontrolą operatora | Zapisać wyłącznie zatwierdzone bajty w zatwierdzonych plikach, zweryfikować efekt i zwrócić go Towarzyszowi do raportu | Zmieniać plan w trakcie wykonania, wykonywać poleceń dostarczonych przez agenta lub samoczynnie publikować |
| Niezależna weryfikacja | Sprawdzić zakres, zawartość po zapisie, testy możliwe do bezpiecznego uruchomienia, raport | Uznawać samego wyniku modelu lub składni za dowód poprawności |

Przepływ: **obserwacja → wniosek z dowodami → propozycja → kontrola danych →
podgląd i decyzja Rafała → ponowna kontrola aktualności → kontrolowany zapis →
weryfikacja → raport**. Odesłanie do poprawy tworzy *nową* propozycję; odrzucenie
kończy ten identyfikator. Awaria, timeout albo niejednoznaczność zatrzymują
przepływ bez dalszego wykonania. Wynik wykonania nie jest tym samym co commit.

**Decyzja Rafała o wykonaniu:** po zatwierdzeniu wspólnie ustalonej, końcowej
wersji Towarzysz ma wykonać tę zmianę i odpowiadać operacyjnie za sprawdzenie
oraz zgłoszenie skutku. Fizyczny zapis wykonuje wydzielony komponent jego
systemu, którego uprawnienia i akceptacja pozostają niezależne od procesu
analitycznego. Przed zapisem komponent porównuje aktualne pliki z zatwierdzoną
wersją; rozbieżność odsyła do nowej decyzji zamiast samodzielnej korekty.

**Granica źródła:** jeden agent na VM nie uzyskuje automatycznie dostępu do
fizycznego laptopa, innych urządzeń ani kont w chmurze. Docelowo kontrolowany
czytnik może pobierać potrzebne dane z dopuszczonych źródeł do prywatnej
analizy porównawczej; to udzielony przez Rafała zakres odczytu, a nie zgoda
na wysyłkę do innych odbiorców, centralną trwałą kopię całego sejfu lub
zapis zmian w chmurze. Kanał połączenia, dane zapytania wysyłane dostawcy,
poświadczenia, limity pobierania, przechowywanie tymczasowe i raport z
dostępu wymagają osobnego projektu i prób negatywnych. Propozycja przekazana
kontrolerowi również może ujawnić nazwy lub fragmenty; podgląd i przepływ
raportów muszą zachować prywatność informacji pochodnych.

## 4. Struktura projektu zmian (docelowa, nazwy robocze)

| Obszar | Odpowiedzialność i granica |
| --- | --- |
| `brain/` i `core/` agenta | Obserwacja, analiza, plan, uzasadnione propozycje; Observer pozostaje domyślny. Zakaz samodzielnego nadawania zgód. |
| Czytniki lokalne i chmurowe | Odczyt tylko z jawnie podłączonych źródeł, bez prawa zapisu; bez przekazania agentowi poświadczeń. Zwracają dane do kontrolowanej analizy porównawczej z ograniczonym czasem życia. |
| `proposal/schema.py` i testy | Wersjonowany format danych i limity: identyfikator, pochodzenie, repo, priorytet, uzasadnienie, dowody, cele, stare i nowe bajty/sumy, typ operacji. Docelowo bez uznawania przesłanego diffu za źródło prawdy. |
| Kanał dostarczenia | Ograniczone przekazanie niezaufanej propozycji. Bez dostępu agenta do prywatnego stanu kontrolera i bez możliwości zmiany jego kodu. Dokładny transport do rozstrzygnięcia. |
| `controller/` (osobny instalacyjnie) | Działa pod zaufaną tożsamością, sam odczytuje aktualny stan repo, liczy diff, klasyfikuje chronione zasoby i odbiera decyzję. Kod i dane kontrolera niedostępne do zapisu agentowi. |
| `executor/` kontrolera | Minimalny zestaw atomowych, ograniczonych operacji na zatwierdzonych ścieżkach; kontrola przed otwarciem, backup i weryfikowalny rollback. Żadnego arbitralnego kodu agenta. |
| `tests/` i scenariusze OS | Testy zwykłe plus negatywne próby z konta agenta: zapis repo, kontrolera, zgody, `.git`, symlinki, podmiana pliku, restart i powtórne użycie decyzji. |
| `docs/` i dziennik decyzji | Macierz wymagań R1–R6, aktualny wynik i ograniczenia, instrukcja operatora oraz historia decyzji bez sekretów. |

Prototyp `cli/proposal_review.py` można wykorzystać do oceny ergonomii, lecz
**nie** jest granicą zaufania. Nie przenosić jego opcji „zatwierdź” do procesu
agenta jako skrótu dla prawdziwej zgody.

## 5. Minimalny kontrakt propozycji i zgody

Propozycja to dane, nie program: jedno repozytorium, jedno zadanie, lista
konkretnych względnych plików, pełny diff wyliczony przez kontroler,
uzasadnienie, dowody wykrycia, stara i nowa treść, wpływ oraz plan cofnięcia.
Rozmiar i liczba plików mają ograniczenia. Path traversal, symlinki, hardlinki,
zagnieżdżone repo, `.git`, kod polityki, konfiguracja uprawnień, nieznany typ
operacji i zmiany binarne domyślnie wymagają odmowy lub odrębnego trybu.
Niepewność co do źródła albo aktualności plików oznacza STOP.

Decyzja obejmuje dokładny zestaw zmian i cel. Po decyzji kontroler ponownie
odczytuje docelowe pliki: jeśli różnią się od zatwierdzonego stanu, zgoda
wygasa. Jedno zatwierdzenie uprawnia do co najwyżej jednej próby. Nowy diff,
nowy zakres, częściowe powodzenie albo retry wymagają nowej decyzji.
Odmowa i uwagi do poprawy nie przekazują agentowi żadnego uprawnienia.

Kontroler nie przyjmuje od agenta poleceń testowych, hooków Git ani skryptów
instalacji. Bezpieczne testy uruchamia tylko z wcześniej dozwolonego katalogu
poleceń w izolowanym kontekście; zakres tej możliwości trzeba jeszcze wybrać.
Nie publikować sekretów, kodu prywatnych projektów, treści propozycji ani
dziennika decyzji do Notion lub zewnętrznego LLM bez osobnej zgody.

### Wyjątek od zakazu przekazania danych (do zaprojektowania)

Zanim dane zostaną wysłane poza zatwierdzony kanał odczytu i prywatnej analizy,
kontroler niezależny od agenta
powinien pokazać Rafałowi: **dokładnego odbiorcę i kanał**, cel i konieczność
przekazania, dokładne pola/treść lub możliwy do sprawdzenia podgląd bajtów,
pochodzenie (urządzenie, konto, projekt), ewentualne sekrety i metadane,
czas przechowywania jeśli znany, alternatywę lokalną oraz zakres jednorazowej
zgody. Rafał może poprawić/redagować zakres, odmówić albo zatwierdzić konkretny
przekaz. Nieznany odbiorca, nieznana treść, nieustalona retencja lub zmiana
pakietu po decyzji oznaczają STOP. Odmowa lokalnej poprawki nie uprawnia do
wysłania jej treści w celu „konsultacji”.

Sam opis i przycisk nie dają gwarancji: agent nie może mieć ogólnego
wyjścia sieciowego ani dostępu do poświadczeń. Zaufany czytnik otrzymuje
tylko potrzebny dostęp do wskazanych źródeł, a każdy inny ruch sieciowy
i kanał pośredni są blokowane. Testy powinny objąć próby przesłania danych przez
LLM, Notion, Todoist, Git push, raporty błędów, DNS/HTTP i wstrzyknięte
instrukcje w analizowanych plikach. Dopóki taka granica i testy nie istnieją,
także czytniki chmurowe pozostają wyłączone. Po wdrożeniu ich wyłącznie
do odczytu nadal inne integracje pozostają zablokowane. Zwykły zapis wyniku w Notion przez
człowieka z innego narzędzia jest odrębnym działaniem człowieka i nie daje
Towarzyszowi stałego dostępu do konta.

## 6. Reguły bezpieczeństwa R1–R6 oraz jakość funkcji

### Odpowiedzialność za błędne decyzje Towarzysza

Towarzysz odpowiada **operacyjnie** za jakość własnych propozycji: przy każdej
podaje źródła i czas obserwacji, przesłanki, niepewność, spodziewany wynik,
możliwe szkody, zakres danych i plików oraz sposób sprawdzenia skutku.
Nie dopisuje dowodów po fakcie. Brak wystarczających przesłanek oznacza
oznaczenie hipotezy i wstrzymanie wykonania. Człowiek może się nie zgodzić;
zgoda człowieka nie usuwa błędu rozumowania agenta i nie zwalnia systemu
z wykrycia odchylenia.

Gdy skutek odbiega od zaakceptowanego zakresu lub testy wskazują regresję:
kontroler przerywa dalsze działania, zachowuje lokalny ślad (bez prywatnej
treści w ogólnych logach), informuje Rafała o tym, co się zmieniło i jaka
jest niepewność, oraz przedstawia możliwość przywrócenia stanu. Automatyczne
cofnięcie jest dozwolone jedynie, jeżeli istnieje uprzednio zatwierdzony,
jednoznaczny i przetestowany scenariusz; inaczej czeka na decyzję.
Po incydencie Towarzysz może przygotować analizę przyczyn i poprawkę do
reguł/testów, ale nie zmienia sam swoich zabezpieczeń ani nie maskuje błędu.

To techniczna rozliczalność, nie przypisywanie oprogramowaniu odpowiedzialności
prawnej lub moralnej. Rafał zachowuje nadzór, a projekt ma ograniczać jego
obciążenie przez czytelny raport, sygnały ostrzegawcze i kontrolowane STOP.

| Reguła / cel | Wymagane domknięcie |
| --- | --- |
| R1 — granica repo | Jedno jawnie wskazane repo na operację; kontrola ścieżki i bieżącej treści w kontrolerze, nie tylko w agencie. |
| R2 — brak eskalacji | Agent bez sudo/root, bez konta operatora i grup dających zapis; uprawnienia sprawdzone rzeczywistą próbą na OS. |
| R3 — ochrona zabezpieczeń | Agent nie zapisuje kodu kontrolera, polityki, jednostek usługi ani własnego kodu uruchomieniowego. Zmiany tych zasobów oddzielnym procesem operatorskim. |
| R4 — brak rozszerzenia celu | Propozycja nie uprawnia do innych projektów, plików, repozytoriów lub kroków „przy okazji”. |
| R5 — analiza osobno | Szerokie, ale świadomie dobrane odczyty; wykonanie tylko przez osobnego kontrolera po decyzji. |
| R6 — odmowa domyślna | Brak zgody, błąd weryfikacji, utrata łączności, nieznana operacja albo niezgodna wersja formatu → STOP z raportem. |
| Trafność i niezawodność | Źródła i dowody obok każdej diagnozy, testy fałszywych alarmów, limity obciążenia CPU/RAM, ograniczenie liczby powiadomień. |
| Odpowiedzialność za błąd | Pełny ślad diagnozy i zatwierdzenia, alarm o regresji, zatrzymanie, raport skutków, kontrolowany rollback i analiza przyczyn bez samodzielnej zmiany reguł. |
| Odwracalność | Backup przed zapisem, brak częściowego batcha, raport powykonawczy i ręczna ścieżka przywrócenia, sprawdzone również po awarii procesu. |
| Prywatność i odpływ danych | Domyślny brak przekazywania danych urządzeń i połączonych kont do innych aplikacji, kont i urządzeń; testy negatywne integracji, jawny opis każdego wyjątku przed decyzją Rafała. |

Priorytet pilnego zgłoszenia nie zmienia żadnej reguły tabeli. Git commit,
push, merge, deployment, usunięcia, właściciel/uprawnienia, systemowe komendy
i dostęp do sekretów są **poza zwykłą zgodą na patch pliku**; potrzebują
oddzielnie zaprojektowanego trybu i świadomego upoważnienia.

## 7. Etapy z bramkami jakości

**Testy kontraktu przed włączeniem zapisów:** brak zgody blokuje PatchEngine
i FileTools; propozycja bez dowodów, źródeł lub ryzyk jest niekompletna;
fałszywe wykrycie nie wywołuje zapisu; zmieniony plik unieważnia zgodę;
awaria po częściowym zapisie daje wykrywalny stan i ścieżkę przywrócenia;
sekret z lokalnego lub chmurowego źródła nie trafia do logu ani niedozwolonego
odbiorcy; wykryta regresja zatrzymuje dalsze działania i zgłasza skutki.
Testy na izolowanym repo i kontach testowych poprzedzają każdy test na danych
rzeczywistych. Zielone testy aplikacji nie zastępują prób uprawnień OS i sieci.

**Sonda kontraktu (25.09.2026, wyłącznie kopia izolowana):** dwa testy celowo
sprawdzające brakujące gwarancje zakończyły się **2 FAIL**. Podgląd przyjął
propozycję bez sprawdzalnych dowodów i ryzyk; `FileTools.write()` zapisał
plik w autoryzowanym repo bez zgody dla patcha. Dane testowe pozostają w
`work/responsibility_probe/`, nie są testem produkcyjnego systemu. Nie
interpretować zielonych 109 testów jako rozwiązania tych dwóch luk.

**Następna sonda częściowej poprawki (wyłącznie kopia izolowana):** publiczne
wejścia `FileTools.write/edit` zablokowano, a zatwierdzony PatchEngine zapisuje
przez `scoped_open`; 109 testów aplikacji przeszło. Z trzech prób kontraktu
**1 PASS, 2 FAIL**: bezpośredni FileTools już nie pisze, ale adapter
`core/observer_storage.open` nadal zapisuje do autoryzowanego repo bez zgody,
a podgląd nadal przyjmuje propozycję bez dowodów. Kod nie został przeniesiony
na laptop i nie stanowi rozwiązania niezależnej zgody. Nawet usunięcie tych
dwóch dróg nie zastępuje separacji kont i kontrolera poza procesem agenta.

1. **Opis i przypadki testowe (teraz):** zatwierdzony zakres obserwacji,
   danych propozycji i klasy operacji. Uzgodnienie nie oznacza włączenia usługi.
2. **Podgląd offline:** uzupełnić obecny terminalowy prototyp o pokazanie
   kontrolerowego diffu i przyjazne uwagi; test odmowy, poprawy, nowego diffu
   oraz braku jakiegokolwiek zapisu po wyborze opcji.
3. **Rozdzielenie OS:** osobny użytkownik agenta, bez grupy `felanraf`, kod
   uruchamiany z niemodyfikowalnej przez agenta lokalizacji, minimalne źródła
   obserwacji i niezależny kontroler. Najpierw plan operacji administracyjnych
   i negatywne testy uprawnień; zmiany usługi dopiero po osobnej zgodzie Rafała.
4. **Jedna bezpieczna klasa zapisów:** kontroler obsługuje w izolowanych
   repozytoriach tylko zaakceptowane tekstowe poprawki, bez Git i shell.
   Potwierdzenie odmowy, aktualności, jednorazowości, transakcyjności i cofnięcia.
5. **Test na rzeczywistym, niekrytycznym projekcie:** wykonanie wyłącznie po
   Twojej decyzji; porównanie przed/po, raport, możliwość zatrzymania i
   przywrócenia. Dopiero potem rozważanie trybu usługi i rozszerzanie funkcji.

Po każdym etapie: wynik testów, aktualna lista luk, jeden następny krok.
Włączenie istniejącego `towarzysz.service` przed etapem 3/4 nie jest bramką
sukcesu. Wszelkie testy wykonania prowadzić na oddzielnym, jawnym repo testowym.

## 8. Decyzje otwarte — bez zgadywania

1. **Zakres odczytu systemu.** Czy pierwsze wydanie ma obejmować tylko
   procesy/usługi, obciążenie, pamięć i dysk, czy także dziennik, sieć oraz
   listę pakietów? Bez tej decyzji nie można ustalić minimalnych uprawnień.
2. **Dostęp agenta do projektów i chmury.** `/home/felanraf` ma obecnie tryb 750, a
   przyszły agent nie może być w grupie `felanraf`. Rafał dopuszcza analizę
   wszystkich swoich plików i porównywanie z danymi chmurowymi; dane mogą
   czasowo trafić do prywatnego kontekstu analizy, bez trwałego kopiowania
   i dalszego eksportu.
   Potrzebna jest architektura lokalnego, zaufanego czytnika pod kontrolą
   operatora, który nie udzieli kontu agenta prawa zapisu ani nie odda mu
   wszystkich poświadczeń. Zakres skanowania ma być funkcjonalny i obejmować
   przydatne pliki, ale nie może samoczynnie eksportować danych. Odczyt kont
   i chmury wymaga kontrolowanych konektorów tylko do odczytu. Nadal trzeba
   ustalić konkretne konta, zakres uprawnień, przechowywanie danych pobranych
   do analizy i kontrolę komunikacji z dostawcą.
3. **Interfejs i powiadomienia.** Terminalowy podgląd już istnieje; czy na
   pierwsze wdrożenie wystarczą lokalne powiadomienia/systemowy dziennik, czy
   potrzebny panel? Kanał nie może dawać agentowi prawa do decyzji. Nie
   ustalono mechanizmu dostarczenia poza konsolę.
4. **Granice wykonywanych operacji.** Propozycja: pierwsze wydanie obsługuje
   wyłącznie małe zmiany tekstowe w jednym repo; usunięcia, Git, instalacje,
   system i uruchamianie testów odkładamy do osobnych decyzji.
5. **Integracje i dane.** Notion jako dziennik postępów jest preferencją
   Rafała, Todoist może być zbędny. Preferencja nie uprawnia Towarzysza do
   przesyłania czegokolwiek. Ustalono nadzór i zgodę na każdy konkretny
   eksport; nadal trzeba rozstrzygnąć, czy przyszły kontroler ma technicznie
   obsługiwać eksport, jakie dane wolno proponować, jak chronić sekret i jak
   wykazać brak niejawnego odpływu danych. Synchronizacja automatyczna nie
   należy do zatwierdzonego zakresu pierwszego wydania.
6. **Awaria i dziennik.** Potrzebny wybór retencji dziennika, miejsca backupu,
   trybu odtwarzania po przerwanym zapisie, limitów obciążenia oraz procedury
   awaryjnego zatrzymania agenta dostępnej Rafałowi.
7. **Dokumentacja historyczna.** Dokumenty V4 w korzeniu projektu mogą być
   mylące. Oznaczyć archiwum i ustalić jedno bieżące źródło statusu, bez
   przepisywania historii i bez publikowania sekretów.

## 9. Czego nie deklarujemy

Obecne 105/109 testów dotyczą opisanych scenariuszy, nie niezależnej zgody,
bezpieczeństwa całego hosta ani trafności diagnoz w produkcji. Usługa nadal
działałaby jako `felanraf`, gdyby ją uruchomić z historycznej konfiguracji.
Kod aplikacji sam nie odizoluje dowolnego Pythona działającego pod tym kontem.
Żadna wstępna propozycja, próbka JSON, odcisk SHA-256 ani przycisk w procesie
agenta nie zastępują granicy kont i kontroli wykonawcy.

**Najbliższy krok do wspólnego rozstrzygnięcia:** zatwierdzić minimalny zakres
obserwacji i jedną klasę zmian obsługiwaną w pierwszej wersji kontrolera.
