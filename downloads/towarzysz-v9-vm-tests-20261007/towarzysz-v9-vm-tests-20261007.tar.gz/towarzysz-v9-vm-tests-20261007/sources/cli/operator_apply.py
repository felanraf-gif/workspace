"""Human-operated, offline application of ONE reviewed text change.

Run from an ordinary operator shell, never inside the agent's sandbox:
    python -B cli/operator_apply.py PROPOSAL.json /absolute/repository

No command-line or environment option bypasses the interactive confirmation.
This controller does not import Towarzysz execution or policy modules.
"""

import hashlib
import json
import os
import secrets
import stat
import sys
from contextlib import contextmanager
from pathlib import Path

if __package__:
    from .proposal_review import load_proposal, render
    from .write_confinement import restrict_writes
else:
    from proposal_review import load_proposal, render
    from write_confinement import restrict_writes


def _is_agent_repository(root):
    return all((root / path).exists() for path in
               ('main.py', 'core/observer_policy.py', 'brain/patch_engine.py'))


@contextmanager
def _target(root, relative):
    """Keep directory and file descriptors open; refuse symlinks and nested repos."""
    parts = relative.split('/')
    if any(not part or part in ('.', '..') or part.startswith('.') for part in parts):
        raise ValueError('Ukryta lub niebezpieczna ścieżka')
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    parent = os.open(root, flags)
    directories = [('', parent, os.fstat(parent))]
    file_fd = None
    try:
        for part in parts[:-1]:
            child = os.open(part, flags, dir_fd=parent)
            parent = child
            directories.append((part, child, os.fstat(child)))
            try:
                os.stat('.git', dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                pass
            else:
                raise PermissionError('Zagnieżdżone repozytorium ma osobny zakres')
        file_fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        info = os.fstat(file_fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise PermissionError('Cel nie jest zwykłym plikiem z jednym dowiązaniem')
        if info.st_uid != os.getuid() or info.st_gid != os.getgid():
            raise PermissionError('Właściciel lub grupa pliku są inne niż operatora')
        yield directories, file_fd, parts[-1], info
    finally:
        if file_fd is not None:
            os.close(file_fd)
        for _, directory_fd, _ in reversed(directories):
            os.close(directory_fd)


def _verify_scope(root, directories):
    """Detect changed directory identities and newly introduced Git boundaries.

    This detects review-time changes. Landlock, not this check, enforces the
    write boundary if another process moves a directory after the check.
    """
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    current = os.open(root, flags)
    try:
        if root != root.resolve(strict=True):
            raise PermissionError('Ścieżka repozytorium zmieniła się')
        for index, (name, _, original) in enumerate(directories):
            if index:
                child = os.open(name, flags, dir_fd=current)
                os.close(current)
                current = child
                try:
                    os.stat('.git', dir_fd=current, follow_symlinks=False)
                except FileNotFoundError:
                    pass
                else:
                    raise PermissionError('Zagnieżdżone repozytorium ma osobny zakres')
            info = os.fstat(current)
            if ((info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid) !=
                    (original.st_dev, original.st_ino, original.st_mode,
                     original.st_uid, original.st_gid)):
                raise PermissionError('Położenie lub tożsamość katalogu zmieniły się')
    finally:
        os.close(current)


def _read_fd(fd, limit):
    os.lseek(fd, 0, os.SEEK_SET)
    data = bytearray()
    while len(data) <= limit:
        chunk = os.read(fd, min(65536, limit + 1 - len(data)))
        if not chunk:
            return bytes(data)
        data.extend(chunk)
    raise ValueError('Plik przekracza limit propozycji')


def _still_same(parent, fd, name, original, expected):
    current = os.stat(name, dir_fd=parent, follow_symlinks=False)
    opened = os.fstat(fd)
    if not stat.S_ISREG(current.st_mode) or current.st_nlink != 1:
        raise PermissionError('Cel został zmieniony w czasie przeglądu')
    if ((current.st_dev, current.st_ino, current.st_mode, current.st_uid, current.st_gid) !=
            (original.st_dev, original.st_ino, original.st_mode, original.st_uid, original.st_gid) or
            (opened.st_dev, opened.st_ino) != (current.st_dev, current.st_ino) or
            _read_fd(fd, len(expected)) != expected):
        raise PermissionError('Treść lub tożsamość pliku zmieniła się; ponów przegląd')


def _replace(root_fd, parent, fd, name, original, expected, replacement):
    temporary = '.towarzysz-operator-' + secrets.token_hex(16)
    temp_fd = None
    created = False
    replaced = False
    try:
        temp_fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                          stat.S_IMODE(original.st_mode), dir_fd=root_fd)
        created = True
        temp_info = os.fstat(temp_fd)
        if (stat.S_IMODE(temp_info.st_mode) != stat.S_IMODE(original.st_mode) or
                temp_info.st_uid != original.st_uid or temp_info.st_gid != original.st_gid):
            raise PermissionError('Nie można zachować właściciela, grupy i trybu pliku')
        view = memoryview(replacement)
        while view:
            written = os.write(temp_fd, view)
            if written <= 0:
                raise OSError('Nie udało się zapisać treści tymczasowej')
            view = view[written:]
        os.fsync(temp_fd)
        os.close(temp_fd)
        temp_fd = None
        _still_same(parent, fd, name, original, expected)
        os.replace(temporary, name, src_dir_fd=root_fd, dst_dir_fd=parent)
        replaced = True
        os.fsync(parent)
        if root_fd != parent:
            os.fsync(root_fd)
    finally:
        if temp_fd is not None:
            os.close(temp_fd)
        if created and not replaced:
            os.unlink(temporary, dir_fd=root_fd)


def _apply_confined(root, directories, fd, name, original, expected, replacement):
    """Only a kernel-confined child may open a writable file or replace it."""
    if not hasattr(os, 'fork'):
        raise PermissionError('Brak obsługi izolowanego procesu zapisu')
    read_fd, write_fd = os.pipe()
    try:
        pid = os.fork()
    except BaseException:
        os.close(read_fd)
        os.close(write_fd)
        raise
    if pid == 0:
        os.close(read_fd)
        try:
            restrict_writes(directories[0][1])
            _verify_scope(root, directories)
            parent = directories[-1][1]
            _still_same(parent, fd, name, original, expected)
            # Stage at the pinned repository root, never in a target directory
            # which another process could move outside the Landlock boundary.
            _replace(directories[0][1], parent, fd, name, original, expected, replacement)
        except BaseException as exc:
            try:
                os.write(write_fd, str(exc).encode('utf-8', errors='replace')[:2048])
            finally:
                os._exit(1)
        os._exit(0)
    os.close(write_fd)
    try:
        message = bytearray()
        while True:
            chunk = os.read(read_fd, 2048)
            if not chunk:
                break
            message.extend(chunk)
    finally:
        os.close(read_fd)
        _, status = os.waitpid(pid, 0)
    if status != 0:
        raise PermissionError(message.decode('utf-8', errors='replace') or
                              'Izolowany proces zapisu nie zakończył się poprawnie')


def main(argv=None, *, input_fn=input, output_fn=print, tty_fn=None):
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 2:
        output_fn('Użycie: python -B cli/operator_apply.py PROPOZYCJA.json /absolutne/repo')
        return 2
    try:
        root = Path(args[1])
        if not root.is_absolute() or root.is_symlink() or root != root.resolve(strict=True):
            raise ValueError('Repozytorium musi mieć rzeczywistą, absolutną ścieżkę')
        if not root.is_dir() or not (root / '.git').is_dir():
            raise ValueError('Brak repozytorium Git')
        if _is_agent_repository(root):
            raise PermissionError('Kod Towarzysza wymaga odrębnego przeglądu poza kontrolerem')
        proposal = load_proposal(args[0])
        if Path(proposal['root']) != root or len(proposal['changes']) != 1:
            raise ValueError('Kontroler wymaga jednego pliku w jawnie wskazanym repozytorium')
        change = proposal['changes'][0]
        if change.get('old_code') is None:
            raise ValueError('Tworzenie i usuwanie plików wymaga odrębnej procedury')
        expected = change['old_code'].encode('utf-8')
        replacement = change['new_code'].encode('utf-8')
        if expected == replacement:
            raise ValueError('Propozycja nie zmienia treści')
        with _target(root, change['path']) as (directories, fd, name, original):
            parent = directories[-1][1]
            _verify_scope(root, directories)
            _still_same(parent, fd, name, original, expected)
            digest = hashlib.sha256(json.dumps(proposal, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':')).encode('utf-8')).hexdigest()
            output_fn(render(proposal))
            phrase = 'ZASTOSUJ ' + digest[:16]
            output_fn('Identyfikator propozycji SHA-256: ' + digest)
            if not (sys.stdin.isatty() if tty_fn is None else tty_fn()):
                raise PermissionError('Wymagany interaktywny terminal operatora')
            if input_fn('Wpisz dokładnie „' + phrase + '” lub Enter, aby odmówić: ') != phrase:
                output_fn('Odmowa: nie zmieniono pliku.')
                return 1
            _still_same(parent, fd, name, original, expected)
            _verify_scope(root, directories)
            _apply_confined(root, directories, fd, name, original, expected, replacement)
        output_fn('Zastosowano jedną zmianę. Sprawdź diff i testy przed dalszym działaniem.')
        return 0
    except (OSError, UnicodeError, ValueError, TypeError, EOFError) as exc:
        output_fn('Nie zastosowano zmiany lub wynik wymaga kontroli: ' + str(exc))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
