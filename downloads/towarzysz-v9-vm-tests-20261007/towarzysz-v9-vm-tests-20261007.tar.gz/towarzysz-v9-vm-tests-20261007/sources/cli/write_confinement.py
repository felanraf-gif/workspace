"""Linux Landlock write boundary for the operator's short-lived child.

No fallback: an unavailable kernel boundary means no application write.
Existing descriptors must be read-only when this restriction is installed.
This confines filesystem effects; it does not separate processes sharing a UID.
"""

import ctypes
import errno
import os
import platform


class _Ruleset(ctypes.Structure):
    _fields_ = [('handled_access_fs', ctypes.c_uint64)]


class _PathRule(ctypes.Structure):
    _pack_ = 1
    _fields_ = [('allowed_access', ctypes.c_uint64), ('parent_fd', ctypes.c_int32)]


def restrict_writes(root_fd):
    """Restrict the calling process permanently; call ONLY in a child."""
    if platform.system() != 'Linux' or platform.machine() not in (
            'x86_64', 'aarch64'):
        raise OSError(errno.ENOSYS, 'Landlock wymaga obsługiwanego systemu Linux')
    libc = ctypes.CDLL(None, use_errno=True)
    libc.syscall.restype = ctypes.c_long
    libc.prctl.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong,
                          ctypes.c_ulong, ctypes.c_ulong]
    libc.prctl.restype = ctypes.c_int

    def syscall(number, *args):
        result = libc.syscall(ctypes.c_long(number), *args)
        if result < 0:
            code = ctypes.get_errno()
            raise OSError(code, 'Landlock niedostępny: ' + os.strerror(code))
        return result

    # ABI 3 includes REFER and TRUNCATE. Handle all filesystem modifications;
    # reads are unrestricted. No writable file is opened before restriction.
    abi = syscall(444, ctypes.c_void_p(), ctypes.c_size_t(0), ctypes.c_uint(1))
    if abi < 3:
        raise OSError(errno.ENOSYS, 'Wymagany Landlock ABI >= 3')
    write_file, remove_dir, remove_file = 1 << 1, 1 << 4, 1 << 5
    make_all = sum(1 << bit for bit in range(6, 13))
    refer, truncate = 1 << 13, 1 << 14
    handled = write_file | remove_dir | remove_file | make_all | refer | truncate
    if abi >= 5:
        handled |= 1 << 15  # IOCTL_DEV: never needed for a text-file replacement.
    ruleset = _Ruleset(handled)
    fd = syscall(444, ctypes.byref(ruleset), ctypes.c_size_t(ctypes.sizeof(ruleset)),
                 ctypes.c_uint(0))
    try:
        allowed = write_file | remove_file | (1 << 8) | refer | truncate
        rule = _PathRule(allowed, root_fd)
        syscall(445, ctypes.c_int(fd), ctypes.c_int(1), ctypes.byref(rule),
                ctypes.c_uint(0))
        if libc.prctl(38, 1, 0, 0, 0):  # PR_SET_NO_NEW_PRIVS
            code = ctypes.get_errno()
            raise OSError(code, 'Nie można zablokować podnoszenia uprawnień')
        syscall(446, ctypes.c_int(fd), ctypes.c_uint(0))
    finally:
        os.close(fd)
