"""Offline proposal preview. This UI cannot approve or execute agent writes.

Usage: python -B cli/proposal_review.py proposal.json
JSON: {"schema_version": 1, "project": "name", "root": "/absolute/repo",
       "description": "reason", "priority": "HIGH",
       "changes": [{"path": "src/module.py", "old_code": "...", "new_code": "..."}]}
"""

import difflib
import json
import sys
import unicodedata
from pathlib import Path, PurePosixPath

MAX_PROPOSAL_BYTES = 1024 * 1024


def _display(value):
    """Keep untrusted proposal text from injecting terminal control sequences."""
    result = []
    for character in value:
        if character in '\n\t':
            result.append(character)
        elif (ord(character) < 32 or ord(character) == 127 or
              0x80 <= ord(character) <= 0x9f or
              unicodedata.category(character) == 'Cf'):
            result.append(f'\\x{ord(character):02x}' if ord(character) < 256
                          else f'\\u{ord(character):04x}')
        else:
            result.append(character)
    return ''.join(result)


def load_proposal(path):
    raw = Path(path).read_bytes()
    if len(raw) > MAX_PROPOSAL_BYTES:
        raise ValueError('Propozycja przekracza limit 1 MiB')
    proposal = json.loads(raw)
    if not isinstance(proposal, dict) or proposal.get('schema_version') != 1:
        raise ValueError('Nieznana wersja propozycji')
    if not all(isinstance(proposal.get(key), str) and proposal[key].strip()
               for key in ('project', 'root', 'description', 'priority')):
        raise ValueError('Brakuje opisu projektu lub priorytetu')
    if proposal['priority'].upper() not in ('HIGH', 'MEDIUM', 'LOW'):
        raise ValueError('Nieznany priorytet')
    if not Path(proposal['root']).is_absolute():
        raise ValueError('Repozytorium musi mieć ścieżkę absolutną')
    changes = proposal.get('changes')
    if not isinstance(changes, list) or not changes:
        raise ValueError('Brak zmian')
    seen = set()
    for change in changes:
        if not isinstance(change, dict) or not all(
                isinstance(change.get(key), str) for key in ('path', 'new_code')):
            raise ValueError('Niekompletna zmiana')
        old = change.get('old_code')
        if old is not None and not isinstance(old, str):
            raise ValueError('Niepoprawna stara treść')
        name = change['path']
        parts = PurePosixPath(name).parts
        if (not name or name.startswith('/') or '\\' in name or
                any(part in ('.', '..', '.git') for part in name.split('/')) or
                name in seen or not parts):
            raise ValueError('Niebezpieczna lub powtórzona ścieżka')
        seen.add(name)
    return proposal


def render(proposal):
    lines = [f"Projekt: {_display(proposal['project'])}",
             f"Repozytorium: {_display(proposal['root'])}",
             f"Priorytet: {_display(proposal['priority'])}",
             f"Powód: {_display(proposal['description'])}",
             f"Pliki: {len(proposal['changes'])}", '']
    for change in proposal['changes']:
        name = change['path']
        before = (change.get('old_code') or '').splitlines(keepends=True)
        after = change['new_code'].splitlines(keepends=True)
        diff_lines = difflib.unified_diff(
            before, after,
            fromfile='a/' + name if change.get('old_code') is not None else '/dev/null',
            tofile='b/' + name)
        diff = ''.join(line if line.endswith('\n') else
                       line + '\n\\ No newline at end of file\n'
                       for line in diff_lines)
        lines.append(_display(diff or f'(Brak zmiany treści: {name})\n'))
    lines.append('PODGLĄD: decyzja nie uruchamia zmian ani nie udziela zgody agentowi.')
    return '\n'.join(lines)


def main(argv=None, input_fn=input, output_fn=print):
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        output_fn('Użycie: python -B cli/proposal_review.py propozycja.json')
        return 2
    try:
        proposal = load_proposal(args[0])
        output_fn(render(proposal))
        choice = input_fn('Decyzja [z]atwierdź / [p]opraw / [o]drzuć: ').strip().lower()
        if choice not in ('z', 'p', 'o'):
            output_fn('Nie wybrano decyzji.')
            return 1
        if choice == 'p':
            note = input_fn('Co należy poprawić? ').strip()
            if not note:
                output_fn('Brak uwag; propozycja nie została odesłana.')
                return 1
            output_fn('Podgląd: odeślij do poprawy: ' + _display(note))
        elif choice == 'o':
            output_fn('Podgląd: odrzuć propozycję.')
        else:
            output_fn('Podgląd: zaznaczono zatwierdzenie; żadna zgoda nie została wystawiona.')
        return 0
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as exc:
        output_fn(f'Nie można wyświetlić propozycji: {exc}')
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
