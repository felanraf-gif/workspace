__all__ = ["CLI"]


def __getattr__(name):
    # The offline operator controller must not import the agent on package load.
    if name == "CLI":
        from .commands import CLI
        return CLI
    raise AttributeError(name)
