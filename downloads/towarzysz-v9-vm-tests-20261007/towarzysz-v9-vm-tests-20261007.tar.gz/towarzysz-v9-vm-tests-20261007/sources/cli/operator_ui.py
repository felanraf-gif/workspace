"""Offline operator UI prototype. It cannot contact Towarzysz or approve writes.

Run: python3 -B cli/operator_ui.py --demo
The interface intentionally has no IPC, network, persistent storage or imports
from the agent. A future trusted controller will provide a separate backend.
"""

import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class DemoProposal:
    project: str = 'Projekt przykładowy'
    target: str = 'example.py'
    priority: str = 'HIGH'
    description: str = 'Przykład: zmiana fikcyjnej wartości w pliku testowym.'
    before: str = 'VALUE = 1\n'
    after: str = 'VALUE = 2\n'


class DemoController:
    """Safe, in-memory example. No operation here returns an approval token."""

    def __init__(self):
        self.proposal = DemoProposal()
        self.messages = []
        self.events = ['DEMO: otwarto interfejs operatora']
        self.decision = None

    def send_message(self, message):
        message = message.strip()
        if not message or len(message) > 1000:
            raise ValueError('Wiadomość musi mieć od 1 do 1000 znaków.')
        self.messages.append(('Rafał', message))
        self.events.append('DEMO: zapisano wiadomość wyłącznie w pamięci')
        return 'Wiadomość zapisana w DEMO; nie wysłano jej do Towarzysza.'

    def review(self, choice, note=''):
        if choice not in ('approve', 'revise', 'reject'):
            raise ValueError('Nieznana decyzja')
        if choice == 'revise' and not note.strip():
            raise ValueError('Podaj uwagę do poprawy.')
        self.decision = choice
        self.events.append({
            'approve': 'DEMO: wybrano „Zatwierdź”; NIE wystawiono zgody',
            'revise': 'DEMO: wybrano „Popraw”; NIE wysłano zadania',
            'reject': 'DEMO: wybrano „Odrzuć”; NIE zmieniono plików',
        }[choice])
        return self.events[-1]


def run_demo():
    import tkinter as tk
    from tkinter import messagebox, simpledialog, ttk
    from difflib import unified_diff

    controller = DemoController()
    root = tk.Tk()
    root.title('Towarzysz — panel Rafała (DEMO)')
    root.geometry('900x650')
    root.minsize(650, 500)
    root.configure(bg='#101827')
    style = ttk.Style(root)
    style.theme_use('clam')
    style.configure('TFrame', background='#101827')
    style.configure('TLabel', background='#101827', foreground='#eaf0f8', font=('Sans', 11))
    style.configure('TButton', padding=(12, 8), font=('Sans', 10))
    style.configure('TNotebook', background='#101827')

    header = ttk.Frame(root, padding=18)
    header.pack(fill='x')
    ttk.Label(header, text='TOWARZYSZ  •  PANEL OPERATORA',
              font=('Sans', 16, 'bold')).pack(anchor='w')
    ttk.Label(header, text='TRYB DEMO · Bez połączenia z agentem · Bez zatwierdzania zapisów',
              foreground='#fbbf24').pack(anchor='w', pady=(7, 0))
    notebook = ttk.Notebook(root)
    notebook.pack(fill='both', expand=True, padx=18, pady=(0, 18))
    talk, proposals, audit = (ttk.Frame(notebook, padding=16) for _ in range(3))
    for title, frame in (('Rozmowa', talk), ('Propozycje', proposals), ('Dziennik', audit)):
        notebook.add(frame, text=title)

    ttk.Label(talk, text='Wiadomość do Towarzysza (tylko w pamięci tego okna)').pack(anchor='w')
    compose = tk.Text(talk, height=5, wrap='word', padx=10, pady=10)
    compose.pack(fill='x', pady=10)
    conversation = tk.Text(talk, state='disabled', wrap='word', padx=10, pady=10)
    conversation.pack(fill='both', expand=True)

    def refresh_conversation():
        conversation.configure(state='normal')
        conversation.delete('1.0', 'end')
        for author, message in controller.messages:
            conversation.insert('end', f'{author}: {message}\n\n')
        conversation.configure(state='disabled')

    def send():
        try:
            messagebox.showinfo('Tryb demo', controller.send_message(compose.get('1.0', 'end')))
            compose.delete('1.0', 'end')
            refresh_conversation()
        except ValueError as exc:
            messagebox.showerror('Błąd wiadomości', str(exc))

    ttk.Button(talk, text='Zapisz wiadomość w DEMO', command=send).pack(anchor='e', pady=10)

    item = controller.proposal
    ttk.Label(proposals, text=f'{item.project}  •  {item.priority}',
              font=('Sans', 14, 'bold')).pack(anchor='w')
    ttk.Label(proposals, text=f'Cel: {item.target}\nPowód: {item.description}').pack(anchor='w', pady=10)
    ttk.Label(proposals, text='Zakres: jeden fikcyjny plik. Podgląd pełnej różnicy:').pack(anchor='w')
    diff = ''.join(unified_diff(item.before.splitlines(keepends=True),
                                item.after.splitlines(keepends=True),
                                fromfile='przed/' + item.target,
                                tofile='po/' + item.target))
    preview = tk.Text(proposals, height=11, wrap='none', padx=10, pady=10)
    preview.insert('1.0', diff)
    preview.configure(state='disabled')
    preview.pack(fill='both', expand=True, pady=10)

    decision_row = ttk.Frame(proposals)
    decision_row.pack(fill='x')

    def choose(choice):
        note = simpledialog.askstring('Popraw propozycję', 'Co należy zmienić?', parent=root) if choice == 'revise' else ''
        if choice == 'revise' and note is None:
            return
        try:
            messagebox.showinfo('Tryb demo', controller.review(choice, note))
        except ValueError as exc:
            messagebox.showerror('Błąd decyzji', str(exc))
        refresh_audit()

    for label, code in (('Zatwierdź (DEMO)', 'approve'), ('Popraw (DEMO)', 'revise'),
                        ('Odrzuć (DEMO)', 'reject')):
        ttk.Button(decision_row, text=label, command=lambda value=code: choose(value)).pack(side='left', padx=(0, 10))

    ttk.Label(audit, text='Lokalny podgląd zdarzeń tego okna',
              font=('Sans', 13, 'bold')).pack(anchor='w')
    ttk.Label(audit, text='Bez historii systemowej; agent nie jest połączony.').pack(anchor='w', pady=8)
    events = tk.Text(audit, state='disabled', wrap='word', padx=10, pady=10)
    events.pack(fill='both', expand=True)

    def refresh_audit():
        events.configure(state='normal')
        events.delete('1.0', 'end')
        events.insert('end', '\n'.join(controller.events))
        events.configure(state='disabled')

    refresh_audit()
    root.mainloop()


if __name__ == '__main__':
    if sys.argv[1:] != ['--demo']:
        raise SystemExit('Użycie: python3 -B cli/operator_ui.py --demo')
    run_demo()
