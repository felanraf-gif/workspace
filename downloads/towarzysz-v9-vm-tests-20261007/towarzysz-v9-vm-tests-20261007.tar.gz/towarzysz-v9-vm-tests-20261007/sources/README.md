# Towarzysz V9

## Aktualizacja chmurowa — 07.10.2026

Źródła uzupełniono z archiwum `towarzysz-v9-M0-audit-20260928.tar.gz`,
bez historii `.git`, sekretów i danych testowych `work/validation`.
Aktualny zakres walidacji i ograniczenia: [STATUS_AKTUALNY.md](STATUS_AKTUALNY.md).

Kontroler `cli/operator_apply.py` wymaga teraz Linux Landlock ABI ≥ 3.
Sprawdza ponownie katalogi po zatwierdzeniu, a zapis wykonuje wyłącznie
w ograniczonym procesie potomnym. Plik tymczasowy powstaje w przypiętym
katalogu głównym repozytorium; przeniesienie podkatalogu docelowego poza
ten zakres powoduje odmowę operacji przez jądro. Brak Landlock blokuje zapis,
bez przejścia do wcześniejszego sposobu wykonania.

Podgląd propozycji pokazuje osobne linie diffu oraz oznaczenie
`No newline at end of file`, gdy treść nie ma końcowego znaku nowej linii.

W chmurze repo i venv mogą leżeć poza HOME. Użyj jawnego katalogu roboczego:

```bash
cd /workspace/workspace
.venv/bin/python -B scripts/observer_sandbox.py \
  --repo /workspace/workspace --python /workspace/workspace/.venv/bin/python \
  --workspace-root /workspace --probe
# Tylko po udanej sondzie: powtórz polecenie bez --probe.
```

Launcher nadal wymaga zaufanego systemowego `bubblewrap` oraz działających
przestrzeni użytkownika. Sam parametr katalogu nie zastępuje tych wymagań.
Nie uruchamiaj usługi ani Buildera. Ręczny kontroler nie jest niezależną
granicą zaufania dla dowolnego złośliwego procesu działającego na tym samym UID.

Towarzysz analizuje projekty i przygotowuje rekomendacje. Domyślnie działa w Observer Mode. Moduły integracji istnieją, lecz ich trwałe skutki są blokowane przez bieżącą politykę.

Ostatni wynik przekazany z VM: **125 PASS, 1 wyłączony**; sonda
`bubblewrap` potwierdziła blokadę zapisu, a jeden cykl Observer zakończył się.
Następne poprawki jakości propozycji wymagają ponownej walidacji na VM.
Szczegóły i granice:
[STATUS_AKTUALNY.md](STATUS_AKTUALNY.md).

Decyzja operacyjna: jedno konto `felanraf`, wyłącznie jednorazowy Observer
Mode do czasu niezależnej kontroli zgód i zapisów. Nie uruchamiać obecnej
usługi systemd: wskazuje starszy katalog `workspace`. Projekty osobnego konta
w `docs/bezpieczenstwo/` są historycznymi propozycjami.

Instalacja zależności testowych: `python3 -m pip install -r requirements-dev.txt` w wybranym środowisku wirtualnym.

## Architektura

```
OBSERVE → ROLES (SCOUT → ARCHITECT → BUILDER → CRITIC) → ANALYZE → PLAN → ALERTS → SAVE → SYNC → INTERACT → REFLECT
```

| Faza | Komponent | Opis |
|------|-----------|------|
| OBSERVE | `brain/observer.py` | Wykrywa zmiany w plikach (hash-based) |
| ROLES | `brain/roles/manager.py` | Cykl agentów: Scout (skan), Architect (plan), Builder (wykonanie), Critic (ewaluacja) |
| ANALYZE | `brain/analyzer.py` | Analiza AST Python, regex JS, wykrywanie problemów |
| PLAN | `brain/planner.py` | Generowanie zadań, priorytetyzacja, wybór fokusu |
| ALERTS | `brain/alerts.py` | Alerty stagnacji i przeterminowania |
| SAVE | `integrations/obsidian.py` | Zapis do Obsidian Vault |
| SYNC | `integrations/todoist.py` | Synchronizacja z Todoist |
| INTERACT | `brain/assistant.py` | Smart check-in, rekomendacje LLM |
| REFLECT | `brain/reflection/` | Samokrytyka, nauka na błędach |

## Struktura

```
towarzysz/
├── core/                    # Główna pętla i konfiguracja
│   ├── loop.py              # Daemon loop
│   ├── config.py            # Konfiguracja z .env
│   └── constants.py         # Stałe systemowe
├── brain/                   # Inteligencja
│   ├── analyzer.py          # Analiza projektów (AST, regex)
│   ├── planner.py           # Planowanie zadań
│   ├── assistant.py         # Interakcja + LLM
│   ├── alerts.py            # Alerty produktywności
│   ├── observer.py          # Detekcja zmian w plikach
│   ├── executor.py          # Wykonawca zadań
│   ├── project_discovery.py # Auto-odkrywanie projektów
│   ├── project_tracker.py   # Śledzenie postępu projektów
│   ├── project_manager.py   # Zarządzanie wieloma projektami
│   ├── project_recommender.py # Rekomendacje projektów
│   ├── roles/               # Agenci ról (Scout, Architect, Builder, Critic)
│   ├── planning/            # Dekompozycja celów, harmonogramowanie
│   └── reflection/          # Samokrytyka, nauka
├── integrations/
│   ├── obsidian.py          # Obsidian Vault
│   ├── todoist.py           # Todoist API
│   ├── standup.py           # Daily Standup
│   └── llm.py               # LLM (Groq / OpenAI / Anthropic)
├── memory/
│   ├── memory.py            # Pamięć centralna (singleton)
│   ├── project_memory.py    # Pamięć per-projekt
│   ├── short.py             # Pamięć krótkoterminowa (TTL)
│   ├── long.py              # Pamięć długoterminowa (JSON)
│   └── vector.py            # Pamięć wektorowa (JSON fallback)
├── tools/                   # System narzędzi
│   ├── executor.py          # Silnik wykonywania
│   ├── registry.py          # Rejestr narzędzi
│   ├── file_tools.py        # Operacje na plikach
│   ├── bash_tools.py        # Polecenia bash/python
│   ├── search_tools.py      # Wyszukiwanie (grep/find)
│   └── git_tools.py         # Operacje git
├── skills/                  # Biblioteka strategii
│   ├── library.py           # Magazyn skilli
│   └── selector.py          # Selekcja skilli
├── cli/commands.py          # Komendy interaktywne
├── reports/reporter.py      # Raporty dzienne
├── tests/                   # Testy regresyjne
├── main.py                  # Punkt wejścia
├── requirements.txt         # Zależności uruchomieniowe
└── requirements-dev.txt     # Zależności testowe
```

## Funkcje

### Multi-Agent (V9)
- **Scout** — skanuje pliki i środowisko
- **Architect** — planuje rozwiązania architektoniczne
- **Builder** — wykonuje zaplanowane zadania narzędziami
- **Critic** — ewaluuje wyniki i sugeruje poprawki
- **RoleManager** — orkiestruje cykl życia agentów

### Analiza kodu
- Parsowanie AST dla Pythona
- Wykrywanie: secrets, TODO/FIXME, długie funkcje, błędy składni
- Generowanie propozycji architektury i roadmap

### Pamięć trójpoziomowa (V9)
- **ShortMemory** — in-memory z TTL (cache kontekstu)
- **LongMemory** — trwała w plikach JSON
- **VectorMemory** — proste wyszukiwanie leksykalne w trwałym magazynie JSON

### System narzędzi (V9)
- File: odczyt plików; bezpośredni zapis i edycja są zablokowane
- Bash: interfejs istnieje, wykonanie jest blokowane
- Search: grep i find po projekcie
- Git: kontrolowane odczyty; add/commit są blokowane

### Produktywność
- Alerty stagnacji (CRITICAL / WARNING / INFO)
- Smart check-in co 30 min
- Rekomendacje LLM (Groq/OpenAI/Anthropic)
- Daily Standup o 6:00
- Project Intelligence dla nowych projektów

## Konfiguracja

```bash
cp .env.example .env
# Edytuj .env — dodaj klucze API
```

Zmienne opcjonalnych integracji (niewymagane w Observer Mode):
```env
TODOIST_API_TOKEN=your_todoist_token
GROQ_API_KEY=your_groq_key
```

## Uruchomienie

Po walidacji na VM uruchamiaj wyłącznie jednorazowy cykl w izolacji
systemowej. Skrypt ustawia ścieżki skanu, wyłącza integracje i włącza
Observer Mode; wymagany jest działający `bubblewrap` z uprawnieniem
do przestrzeni użytkownika. Przykład dla repozytorium audytowego:

```bash
cd /home/felanraf/Projekty/towarzysz-v9-audit-20260925 || exit 1
PYTHON=/home/felanraf/Projekty/towarzysz-v9-agent-clean/.venv/bin/python
"$PYTHON" -B scripts/observer_sandbox.py \
  --repo "$PWD" --python "$PYTHON" --probe &&
"$PYTHON" -B scripts/observer_sandbox.py \
  --repo "$PWD" --python "$PYTHON"
```

Nie używać na tym etapie `run_da.sh` ani starej usługi systemd. Launcher
`run_da.sh` tworzy log i PID nawet w Observer Mode; usługa wskazuje inne
repozytorium. Sonda sprawdza blokadę zapisu w jednym pliku; dla weryfikacji
braku zmian w całym repozytorium potrzebny jest osobny pomiar przed i po cyklu.

## CLI

| Komenda | Opis |
|---------|------|
| `/intel <projekt>` | Generuj Project Intelligence |
| `/focus` | Pokaż aktualny fokus |
| `/status` | Status systemu |
| `/plan` | Plan na dziś |
| `/now` | Co teraz? |
| `/help` | Lista komend |

## Testowanie

```bash
PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 .venv/bin/python -B scripts/validate.py
```

## Integracje

| System | Zakres |
|--------|--------|
| **Obsidian** | Daily notes, Project Intelligence, Standup, dokumentacja |
| **Todoist** | Taski z priorytetami, etykietą FOCUS, deduplikacja |
| **LLM** | Groq (domyślnie), OpenAI, Anthropic |

## Bezpieczeństwo

- Domyślny start działa w `OBSERVER_MODE=true` i blokuje trwałe skutki.
- `AUTHORIZED_REPO` jest przejmowane wyłącznie ze środowiska procesu przed
  załadowaniem `.env`; wartości `AUTHORIZED_REPO`, `OBSERVER_MODE` i
  `TOWARZYSZ_APPROVED_PATCH_SHA256` z `.env` są ignorowane.
- Kontrolowane zapisy są ograniczone do autoryzowanego repozytorium; blokowane
  są m.in. wyjścia przez `..`, symlinki, hardlinki, zagnieżdżone repozytoria i `.git`.
- Odczyty Git wyłączają hooki, filtry, zewnętrzne diffy, rekursję submodułów i
  formaty uruchamiające weryfikatory podpisów.
- PatchEngine nie wykonuje stagingu ani commitów.
- W poprawce roboczej jedynie PatchEngine otwiera okno zapisu dla zatwierdzonej
  paczki; stan runtime pozostaje w RAM. Ręczny rollback wymaga odrębnej
  procedury przeglądu i nie jest obecnie dostępny.
- Jest to polityka aplikacyjna, nie sandbox systemu operacyjnego. R3/R4 i pełny
  przepływ jednorazowej zgody pozostają dalszym etapem hardeningu.

### Oddzielony operator: etap roboczy

`scripts/observer_sandbox.py` uruchamia **jeden cykl Observer Mode** przez
`bubblewrap`: repo i środowisko Pythona są montowane tylko do odczytu,
katalog domowy poza nimi jest ukryty, a przestrzeń sieciowa odłączona. Najpierw
sprawdzić blokadę zapisu na VM (tworzy i usuwa tymczasowy katalog w repo):

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -B scripts/observer_sandbox.py \
  --repo /home/felanraf/Projekty/towarzysz-v9-audit-20260925 \
  --python /home/felanraf/Projekty/towarzysz-v9-agent-clean/.venv/bin/python --probe
```

Jeśli sonda nie zgłosi `OK`, nie uruchamiać przez ten launcher; nie zastępować
go bezpośrednim startem w trybie wykonawczym. Po udanej sondzie pominięcie
`--probe` uruchamia jeden cykl. Ta ścieżka wymaga dostępnego `bubblewrap` i
działających przestrzeni nazw użytkownika na VM; nie instalowano usługi.

`cli/operator_apply.py` działa wyłącznie w terminalu operatora, **poza**
sandboxem agenta. Przyjmuje opis konkretnej zmiany w formacie
`cli/proposal_review.py`, wymaga istniejącego pliku i zgodnej starej treści,
pokazuje diff oraz SHA-256 propozycji i wymaga wpisania pełnego potwierdzenia.
Może zmienić tylko jeden plik w podanym repo; odmawia zmian w repo Towarzysza,
dowiązań, zagnieżdżonych repo, tworzenia plików, automatycznej zgody i
uruchomienia bez terminala. Nie wykonuje Git, poleceń systemowych ani sieci.
Obecne 9 zadań Observera to **pomysły**, nie kompletne opisy zatwierdzalnych
zmian; nie ma jeszcze automatycznego eksportu zadań do tego formatu.

Kontroler i launcher są nową poprawką roboczą. Do sprawdzenia sondy oraz
regresji na VM pozostają wyłączone operacyjne zapisy przez agenta. Nawet po
udanej sondzie sandbox chroni ten jeden proces, nie inne aplikacje tego samego
użytkownika; nie dowodzi braku innych kanałów komunikacji ani integralności
wszystkich danych na komputerze.

## Wersje

- **V9** — Multi-agent, pamięć 3-poziomowa, narzędzia, refleksja, skills
- **V8** — Refaktoryzacja, bezpieczeństwo, szczegółowe taski
- **V7** — Smart check-in, Project Intelligence
- **V4-V6** — Archiwum w `modules_archive/`

## Ograniczenia

Tylko jawne `OBSERVER_MODE=false` wyłącza obserwację; inne wartości pozostawiają blokadę. `auto_confirm=False` odmawia zastosowania patchy, lecz nie stanowi pełnego mechanizmu zgód. Ignorowanie submodułów ogranicza kompletność metryk Git. Po zamknięciu bezpośrednich ścieżek zapisu walidacja na VM dała 115 PASS, 1 test celowo wyłączony, a pojedynczy cykl Observer Mode nie zmienił plików repozytorium. Sama kontrola w procesie agenta nie jest niezależną autoryzacją człowieka; tryb wykonawczy nie jest gotowy do pracy na rzeczywistych plikach.
