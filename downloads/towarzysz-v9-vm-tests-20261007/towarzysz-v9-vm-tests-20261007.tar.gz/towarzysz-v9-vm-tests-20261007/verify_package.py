"""Verify the exact ordinary files in this package without executing sources."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def verify(root):
    manifest = json.loads((root / 'PACKAGE_SHA256.json').read_text())
    for name, expected in manifest.items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe manifest path')
        path = root / name
        if any(part.is_symlink() for part in (path, *path.parents)):
            raise ValueError('Symlink: ' + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Checksum mismatch: ' + name)
    actual = {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()}
    if actual != set(manifest) | {'PACKAGE_SHA256.json'}:
        raise ValueError('Unexpected or missing package files')
    print(f'OK: {len(manifest)} files verified')


if __name__ == '__main__':
    verify(Path(__file__).resolve().parent)
